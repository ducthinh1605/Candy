﻿namespace ECommerce.API.Models
{
    public class cart
    {
        public int Id { get; set; }
        public int qty { get; set; }
        public int total_price { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public User users_id { get; set; } = new User();
        public product pro_id { get; set; } = new product();
    }
}
