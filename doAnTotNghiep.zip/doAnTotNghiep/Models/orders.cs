﻿namespace ECommerce.API.Models
{
    public class orders
    {
        public int Id { get; set; }
        public string OrderName { get; set; } = string.Empty;
        public int OrderPhone { get; set; }
        public string OrderCity { get; set; } = string.Empty;
        public string OrderDistrict { get; set; } = string.Empty;
        public string OrderWard { get; set; } = string.Empty;
        public string OrderStreet { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
        public int status { get; set; }
        public int total { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public admin AdminId { get; set; } = new admin();
        public User UsersId { get; set; } = new User();
        public paymentMethod PmId { get; set; } = new paymentMethod();
    }
}
