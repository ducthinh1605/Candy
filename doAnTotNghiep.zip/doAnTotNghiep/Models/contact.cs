﻿namespace ECommerce.API.Models
{
    public class contact
    {
        public int Id { get; set; }
        public int Status { get; set; }

        public string Content { get; set; } = string.Empty;
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }
        public User user { get; set; } = new User();
    }
}
