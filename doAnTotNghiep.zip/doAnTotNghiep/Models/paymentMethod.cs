﻿namespace ECommerce.API.Models
{
    public class paymentMethod
    {
        public int Id { get; set; }
        public string paymentName { get; set; }
        public int isAvailable { get; set; }
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }
    }
}
