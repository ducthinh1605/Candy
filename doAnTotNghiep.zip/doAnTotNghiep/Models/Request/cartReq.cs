﻿namespace ECommerce.API.Models.Request
{
    public class cartReq
    {
        public int Id { get; set; }
        public int qty { get; set; }
        public int discount_price { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public int users_id { get; set; }
        public int pro_id { get; set; }
    }
}
