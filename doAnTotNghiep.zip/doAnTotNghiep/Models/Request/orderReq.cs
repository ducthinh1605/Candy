﻿namespace ECommerce.API.Models.Request
{
    public class orderReq
    {
        public int Id { get; set; } = 0;
        public string OrderName { get; set; } = string.Empty;
        public int OrderPhone { get; set; } = 0;
        public string OrderCity { get; set; } = string.Empty;
        public string OrderDistrict { get; set; } = string.Empty;
        public string OrderWard { get; set; } = string.Empty;
        public string OrderStreet { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
        public int status { get; set; } = 0;
        public int total { get; set; } = 0;
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public int AdminId { get; set; } = 0;
        public int UsersId { get; set; } = 0;
        public int PmId { get; set; } = 0;
    }
}
