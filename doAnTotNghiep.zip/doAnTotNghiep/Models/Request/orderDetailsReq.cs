﻿namespace ECommerce.API.Models.Request
{
    public class orderDetailsReq
    {
        public int pro_id { get; set; }
        public int order_id { get; set; }
        public int qty { get; set; }
        public int discount_price { get; set; }
        public int total_price { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
