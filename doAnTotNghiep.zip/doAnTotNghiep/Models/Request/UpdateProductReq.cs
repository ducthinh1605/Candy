﻿//namespace ECommerce.API.Models.Request
//{
//    public class UpdateProductReq
//    {
//        public int id { get; set; }
//        public string name { get; set; }
//        public string pakage { get; set; }
//        public int price { get; set; }
//        public int qty { get; set; }
//        public string img { get; set; }
//        public string description { get; set; }
//        public DateTime expied { get; set; }
//        public int cate_id { get; set; }
//        public int sup_id { get; set; }
//        public DateTime Created_at { get; set; }
//        public DateTime Updated_at { get; set; }

//    }
//}
namespace ECommerce.API.Models.Request
{
    public class UpdateProductReq
    {
        public int id { get; set; }
        public string name { get; set; }
        public string pakage { get; set; }
        public int price { get; set; }
        public int qty { get; set; }
        public string img { get; set; }
        public string description { get; set; }
        public DateTime expied { get; set; }
        public int cate_id { get; set; }
        public int sup_id { get; set; }
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }
        public List<string> Images { get; set; }
    }

    public class ProductImage
    {
        public string sub_img { get; set; }
    }
}

