﻿namespace ECommerce.API.Models.Request
{
    public class product_IMGReq
    {
        public int id { get; set; }
        public string img { get; set; } = string.Empty;
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }
        public int proId { get; set; }
    }
}
