﻿namespace ECommerce.API.Models
{
    public class suplier
    {
        public int id { get; set; }
        public string name { get; set; } = string.Empty;
        public string img { get; set; } = string.Empty;
        public string website { get; set; } = string.Empty;
        public string description { get; set; } = string.Empty;
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }


    }
}
