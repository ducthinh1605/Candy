﻿using System;
using Newtonsoft.Json;
namespace ECommerce.API.Models
{
    public class cate
    {
        [JsonIgnore]
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }
    }
}
