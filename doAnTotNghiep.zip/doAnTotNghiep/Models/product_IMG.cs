﻿namespace ECommerce.API.Models
{
    public class product_IMG
    {
        public int id { get; set; }
        public string img { get; set; } = string.Empty;
        public product pro_id { get; set; } = new product();
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }
    }
}
