﻿namespace ECommerce.API.Models
{
    public class orderDetails
    {
        public product pro_id { get; set; } = new product();
        public orders order_id { get; set; } = new orders();
        public int qty { get; set; }
        public int discount_price { get; set; }
        public int total_price { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
