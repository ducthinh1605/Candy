﻿namespace ECommerce.API.Models
{
    public class product
    {
        public int id { get; set; }
        public string name { get; set; } = string.Empty;
        public string pakage { get; set; } = string.Empty;
        public int price { get; set; }
        public int qty { get; set; }
        public string img { get; set; } = string.Empty;
        public string description { get; set; } = string.Empty;
        public DateTime expired { get; set; }
        public cate category { get; set; } = new cate();
        public suplier sup { get; set; } = new suplier();
        public DateTime Created_at { get; set; }
        public DateTime Updated_at { get; set; }
    }
}
