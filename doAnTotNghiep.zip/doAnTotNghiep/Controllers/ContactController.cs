﻿using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        readonly IContact dataAccess;

        public ContactController(IContact dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }


        [HttpPost("InsertContact")]
        public IActionResult insertContact(contactReq contact)
        {

            var result = dataAccess.insertContact(contact);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpGet("GetContact")]
        public IActionResult GetContact()
        {
            var result = dataAccess.GetContact();
            return Ok(result);
        }
        [HttpGet("GetTotalOfContact")]
        public IActionResult GetTotalContacts()
        {
            var result = dataAccess.GetTotalContacts();
            return Ok(result);
        }
        [HttpDelete("Delete")]
        public IActionResult DeleteContact(int contactId)
        {
            var result = dataAccess.DeleteContact(contactId);
            return Ok(result ? "deleted" : "delete fail");
        }
        [HttpPut("SetStatus")]
        public IActionResult SetContactStatus(int contactId, int status)
        {
            var result = dataAccess.SetContactStatus(contactId, status);
            return Ok(result ? "updated" : "update fail");
        }
    }
}