﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductIMGController : ControllerBase
    {
        readonly IProduct_IMG dataAccess;

        public ProductIMGController(IProduct_IMG dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }


        [HttpPost("InsertProduct_IMG")]
        public IActionResult InsertProduct_img(product_IMGReq product_img)
        {

            var result = dataAccess.InsertProduct_img(product_img);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpGet("GetProduct_IMG")]
        public IActionResult GetProduct_img()
        {
            var result = dataAccess.GetProduct_img();
            return Ok(result);
        }
        [HttpGet("GetProduct_img/{id}")]
        public IActionResult GetProduct_imgById(int id)
        {
            var result = dataAccess.GetProduct_imgById(id);
            return Ok(result);
        }
        [HttpGet("GetProduct_imgbypro")]

        public IActionResult GetProductImagesByProductId(int productId)
        {
            var result = dataAccess.GetProductImagesByProductId(productId);
            return Ok(result);
        }


        [HttpPut("UpdateProduct_img/id")]
        public IActionResult UpdateProduct_img(product_IMGReq product_img)
        {

            var result = dataAccess.UpdateProduct_img(product_img);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpDelete("DeleteProduct")]
        public IActionResult DeleteProduct_img(int id)
        {
            var result = dataAccess.DeleteProduct_img(id);
            return Ok(result ? "deleted" : "delete fail");
        }
        [HttpGet("GetTotalOfProductIMG")]
        public IActionResult GetTotalOfProIMG()
        {
            var result = dataAccess.GetTotalOfProIMG();
            return Ok(result);
        }
    }
}
