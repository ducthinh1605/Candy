﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OderDetailController : ControllerBase
    {
        readonly IOrderDetail dataAccess;

        public OderDetailController(IOrderDetail dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }

        [HttpGet("GetOrderDetails")]
        public IActionResult GetOrderDetails(int orderId)
        {
            var result = dataAccess.GetOrderDetails(orderId);
            return Ok(result);
        }

        [HttpGet("GetOrderDetailsByUserID")]
        public IActionResult GetORDByUserID(int userId)
        {
            var result = dataAccess.GetORDByUserID(userId);
            return Ok(result);
        }
        [HttpPost("insertOrder")]
        public IActionResult InsertOrder(orderReq order)
        {

            var result = dataAccess.InsertOrder(order);
            return Ok(result ? "insertted" : "insert fail");
        }
        [HttpPost("sendMail")]
        public IActionResult SendEmailToUser(int userId)
        {
            // Xử lý mã xác thực và gửi email ở đây
            var result = dataAccess.SendEmailToUser(userId);
            // Trả về kết quả phù hợp
            return Ok(result ? "sended" : "sended fail");
        }
    }
}
