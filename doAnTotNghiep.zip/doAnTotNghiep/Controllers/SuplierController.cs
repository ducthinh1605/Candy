﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;


namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SuplierController : ControllerBase
    {
        readonly Isuplier dataAccess;
        private readonly string DateFormat;
        public SuplierController(Isuplier dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;
            DateFormat = configuration["Constants:DateFormat"];
        }


        [HttpPost("InsertSupplier")]
        public IActionResult insertSup(suplier sup)
        {

            var result = dataAccess.insertSup( sup);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpGet("GetSupplier")]
        public IActionResult GetSup()
        {
            var result = dataAccess.GetSup();
            return Ok(result);
        }
        [HttpGet("GetSupplier/{id}")]
        public IActionResult GetSupById(int id)
        {
            var result = dataAccess.GetSupById(id);
            return Ok(result);
        }
        [HttpPut("UpdateSupplier")]
        public IActionResult UpdateSup(suplier sup)
        {
            var result = dataAccess.UpdateSup(sup);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpDelete("DeleteSupplier")]
        public IActionResult DeleteSup(int id)
        {
            var result = dataAccess.DeleteSup(id);
            return Ok(result ? "deleted" : "delete fail");
        }
        [HttpGet("GetTotalOfSup")]
        public IActionResult GetTotalOfSup()
        {
            var result = dataAccess.GetTotalOfSup();
            return Ok(result);
        }
    }
}
