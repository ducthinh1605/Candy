﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        readonly IUserService dataAccess;
        private readonly string DateFormat;
        public UserController(IUserService dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;
            DateFormat = configuration["Constants:DateFormat"];
        }

        [HttpPost("RegisterUser")]
        public IActionResult RegisterUser(User user)
        {

            var result = dataAccess.InsertUser(user);
            return Ok(result ? "inserted" : "insertfail");
        }

        [HttpPost("LoginUser")]
        public IActionResult LoginUser(User user)
        {
            var result = dataAccess.GetUserByAccAndPassword(user);

            return Ok(result ? "yes" : "no");
        }
        [HttpGet("GetUser/{id}")]
        public IActionResult GetUser(int id)
        {
            var result = dataAccess.GetUser(id);
            return Ok(result);
        }
        [HttpGet("GetUsers")]
        public IActionResult GetAllUser()
        {
            var result = dataAccess.GetAllUser();
            return Ok(result);
        }
        [HttpDelete("Delete")]
        public IActionResult Delete(int id)
        {
            var result = dataAccess.Delete(id);
            return Ok(result?"deleted" : "delete fail");
        }

        [HttpPut("Update")]
        public IActionResult Update(User user)
        {
            var result = dataAccess.Update(user);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpGet("GetTotalOfUser")]
        public IActionResult GetTotalOfUser()
        {
            var result = dataAccess.GetTotalOfUser();
            return Ok(result);
        }
        [HttpGet("GetUserInfo")]
        public IActionResult GetUserInfo(string account, string password)
        {
            var result = dataAccess.GetUserInfo(account, password);
            return Ok(result);
        }

        [HttpPost("sendVerification")]
        public IActionResult SendVerificationCodeEmail(string email)
        {
            // Xử lý mã xác thực và gửi email ở đây
            var result = dataAccess.SendVerificationCodeEmail(email);
            // Trả về kết quả phù hợp
            return Ok(result ? "sended" : "sended fail");
        }
        [HttpPost("compareKey")]
        public IActionResult CompareVerificationCode(int userInput)
        {
            var result = dataAccess.CompareVerificationCode(userInput);

            return Ok(new { status = result ? "verified" : "fail", message = result ? "Verification successful" : "Verification failed" });
        }
        [HttpGet("GetAllUserOrderByLatest")]
        public IActionResult GetAllUserOrderByLatest()
        {
            var result = dataAccess.GetAllUserOrderByLatest();
            return Ok(result);
        }
        [HttpGet("GetAllUserOrderByName")]
        public IActionResult GetAllUserOrderByName()
        {
            var result = dataAccess.GetAllUserOrderByName();
            return Ok(result);
        }
    }
}

