﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController: ControllerBase
    {
        readonly IProduct dataAccess;

        public ProductController(IProduct dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }


        //[HttpPost("InsertProduct")]
        //public IActionResult InsertProduct(UpdateProductReq product)
        //{

        //    var result = dataAccess.InsertProduct(product);
        //    return Ok(result ? "inserted" : "insert fail");
        //}
        [HttpPost("InsertProduct")]
        public IActionResult InsertProduct(UpdateProductReq product)
        {
            var result = dataAccess.InsertProduct(product);
            if (result)
            {
                return Ok(new { message = "inserted" });
            }
            else
            {
                return Ok(new { message = "insert fail" });
            }
        }
        [HttpPut("UpdateProduct/id")]
        public IActionResult UpdateProduct(UpdateProductReq id)
        {

            var result = dataAccess.UpdateProduct(id);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpDelete("DeleteProduct")]
        public IActionResult Delete(int id)
        {
            var result = dataAccess.DeleteProduct(id);
            return Ok(result ? "deleted" : "delete fail");
        }
        [HttpGet("GetProduct")]
        public IActionResult GetProducts()
        {
            var result = dataAccess.GetProducts();
            return Ok(result);
        }
        [HttpGet("GetProduct/{id}")]
        public IActionResult GetProductById(int id)
        {
            var result = dataAccess.GetProductById(id);
            return Ok(result);
        }
        [HttpGet("GetTotalOfProduct")]
        public IActionResult GetTotalOfPro()
        {
            var result = dataAccess.GetTotalOfPro();
            return Ok(result);
        }
        [HttpGet("GetProductIMG")]
        public IActionResult GetProductImagesById(int productId)
        {
            var result = dataAccess.GetProductImagesById(productId);
            return Ok(result);
        }
        [HttpGet("GetProductByCategory")]
        public IActionResult GetProductsByCategory(string nameCategory, int count)
        {
            var result = dataAccess.GetProductsByCategory( nameCategory,  count);
            return Ok(result);
        }
        [HttpGet("GetProductBySupplier")]
        public IActionResult GetProductsBySupplier(string nameSupplier, int count)
        {
            var result = dataAccess.GetProductsBySupplier(nameSupplier, count);
            return Ok(result);
        }
        [HttpGet("search")]
        public IActionResult SearchProductsByName(string keyword)
        {
            var matchedProduct = dataAccess.SearchProductsByName(keyword);

            if (matchedProduct == null)
            {
                return NotFound("false");
            }
            return Ok(matchedProduct);
        }
        [HttpGet("GetSmiliarProduct")]
        public IActionResult GetSimilarProductsByCategory(int productId)
        {
            var result = dataAccess.GetSimilarProductsByCategory(productId);
            return Ok(result);
        }
        [HttpGet("GetTopSale")]
        public IActionResult GetTopSellingProducts()
        {
            var result = dataAccess.GetTopSellingProducts();
            return Ok(result);
        }
        [HttpGet("GetNewestProduct")]
        public IActionResult GetLatestProducts()
        {
            var result = dataAccess.GetLatestProducts();
            return Ok(result);
        }
        [HttpGet("GetProductsByExpiration")]
        public IActionResult GetProductsByExpirationDescending()
        {
            var result = dataAccess.GetProductsByExpirationDescending();
            return Ok(result);
        }

    }
}
