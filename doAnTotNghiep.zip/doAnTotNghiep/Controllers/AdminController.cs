﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        readonly IAdmin dataAccess;

        public AdminController(IAdmin dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }

        [HttpPost("Insert")]
        public IActionResult InsertAdmin(admin ad)
        {

            var result = dataAccess.InsertAdmin(ad);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpGet("GetAdmins")]
        public IActionResult GetAdmin()
        {
            var result = dataAccess.GetAdmin();
            return Ok(result);
        }
        [HttpGet("GetAdmin/{id}")]
        public IActionResult GetAdminById(int id)
        {
            var result = dataAccess.GetAdminById(id);
            return Ok(result);
        }
        [HttpPost("LoginAdmin")]
        public IActionResult LoginAdmin(admin ad)
        {
            var result = dataAccess.GetAdminByAccAndPassword(ad);

            return Ok(result ? "yes" : "no");
        }

        [HttpPut("Update")]
        public IActionResult Update(admin ad)
        {
            var result = dataAccess.Update(ad);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpGet("GetAdminId")]
        public IActionResult GetAdminId(string account, string password)
        {
            var result = dataAccess.GetAdminId(account, password);
            return Ok(result);
        }
    }
    
}