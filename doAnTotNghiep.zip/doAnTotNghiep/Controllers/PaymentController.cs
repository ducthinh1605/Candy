﻿using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;
using ECommerce.API.DataAccess;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        readonly Ipayment dataAccess;

        public PaymentController(Ipayment dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }


        [HttpPost("InsertPayment")]
        public IActionResult InserPayment(paymentMethod pay)
        {
            var result = dataAccess.InsertPayment(pay);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpGet("GetPayment")]
        public IActionResult GetPaymentById(int paymentId)
        {
            var result = dataAccess.GetPaymentById(paymentId);
            return Ok(result);
        }
    }
    }