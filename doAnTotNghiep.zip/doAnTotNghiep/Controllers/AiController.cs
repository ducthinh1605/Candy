﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using ECommerce.API.DataAccess;

namespace ECommerce.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AiController : ControllerBase
    {
        private readonly IOpenAi _openAiService;

        public AiController(IOpenAi AiService)
        {
            _openAiService = AiService;
        }

        [HttpPost("generate-text")]
        public async Task<IActionResult> GenerateText([FromBody] TextRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Prompt))
            {
                return BadRequest("Prompt is required.");
            }

            try
            {
                var generatedText = await _openAiService.GenerateTextAsync(request.Prompt);
                return Ok(new { GeneratedText = generatedText });
            }
            catch (System.Exception ex)
            {
                // Xử lý các lỗi phát sinh
                return StatusCode(500, "An error occurred: " + ex.Message);
            }
        }
    }

    public class TextRequest
    {
        public string Prompt { get; set; }
    }
}