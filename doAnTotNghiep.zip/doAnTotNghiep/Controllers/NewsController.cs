﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NewsController : ControllerBase
    {
        readonly Inews dataAccess;
        public NewsController(Inews dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;
        }


        [HttpPost("InsertNews")]
        public IActionResult insertNews(newsReq newreq)
        {
            var result = dataAccess.insertNews(newreq);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpPut("UpdateNews")]
        public IActionResult updateNews(newsReq newreq)
        {
            var result = dataAccess.updateNews(newreq);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpGet("GetNews")]
        public IActionResult GetAllNews()
        {
            var result = dataAccess.GetAllNews();
            return Ok(result);
        }
        [HttpDelete("Delete")]
        public IActionResult deleteNews(int newsId)
        {
            var result = dataAccess.deleteNews(newsId);
            return Ok(result ? "deleted" : "delete fail");
        }
        [HttpGet("GetnewsById")]
        public IActionResult GetNewsById(int newsId)
        {
            var result = dataAccess.GetNewsById(newsId);
            return Ok(result);
        }
        [HttpGet("GetTotalOfNews")]
        public IActionResult GetTotalNews()
        {
            var result = dataAccess.GetTotalNews();
            return Ok(result);
        }
    }
}