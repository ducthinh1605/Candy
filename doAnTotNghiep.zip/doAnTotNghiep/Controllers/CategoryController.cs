﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;


namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        readonly Icate dataAccess;
        private readonly string DateFormat;
        public CategoryController(Icate dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;
            DateFormat = configuration["Constants:DateFormat"];
        }


        [HttpPost("InsertCategory")]
        public IActionResult insertCate(cate category)
        {

            var result = dataAccess.insertCate(category);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpGet("GetCategory")]
        public IActionResult GetCate()
        {
            var result = dataAccess.GetCate();
            return Ok(result);
        }
        [HttpGet("GetCate/{id}")]
        public IActionResult GetCateById(int id)
        {
            var result = dataAccess.GetCateById(id);
            return Ok(result);
        }
        [HttpPut("UpdateCategory")]
        public IActionResult UpdateCate(cate category)
        {
            var result = dataAccess.UpdateCate(category);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpDelete("Delete")]
        public IActionResult DeleteCate(int id)
        {
            var result = dataAccess.DeleteCate(id);
            return Ok(result ? "deleted" : "delete fail");
        }
        [HttpGet("GetTotalOfCate")]
        public IActionResult GetTotalOfCate()
        {
            var result = dataAccess.GetTotalOfCate();
            return Ok(result);
        }
    }
}
