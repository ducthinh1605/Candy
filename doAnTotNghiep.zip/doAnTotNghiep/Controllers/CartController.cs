﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        readonly Icart dataAccess;

        public CartController(Icart dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }

        [HttpPost("InsertCart")]
        public IActionResult InsertCart(int userId, int productId, int qty)
        {
            var result = dataAccess.InsertCart(userId, productId, qty);
            return Ok(result ? "inserted" : "insert fail");
        }
        [HttpDelete("DeleteCart")]
        public IActionResult DeleteCartItem(int userId, int productId)
        {
            var result = dataAccess.DeleteCartItem(userId, productId);
            return Ok(result ? "deleted" : "delete fail");
        }
        [HttpGet("GetCart")]
        public IActionResult GetCart(int userId)
        {
            var result = dataAccess.GetCart(userId);
            return Ok(result);
        }
        [HttpPut("UpdateCart")]
        public IActionResult UpdateCart(int userId, int productId, int newQty)
        {

            var result = dataAccess.UpdateCart(userId, productId, newQty);
            return Ok(result ? "updated" : "update fail");
        }



    }
}