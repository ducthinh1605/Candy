﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using ECommerce.API.Models.Request;

namespace ECommerce.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        readonly IOrder dataAccess;

        public OrderController(IOrder dataAccess, IConfiguration configuration)
        {
            this.dataAccess = dataAccess;

        }

        //[HttpPut("insertOrder")]
        //public IActionResult InsertOrder(orderReq order)
        //{

        //    var result = dataAccess.InsertOrder(order);
        //    return Ok(result ? "updated" : "update fail");
        //}
        [HttpGet("GetAllOrders")]
        public IActionResult GetOrders()
        {
            var result = dataAccess.GetOrders();
            return Ok(result);
        }
        [HttpGet("GetOrder")]
        public IActionResult GetOrdersById(int id)
        {
            var result = dataAccess.GetOrdersById(id);
            return Ok(result);
        }
        [HttpGet("GetOrderTotal")]
        public IActionResult GetTotalOrders()
        {
            var result = dataAccess.GetTotalOrders();
            return Ok(result);
        }
        [HttpPut("SetStatus")]
        public IActionResult SetOrderStatus(int orderId, int newStatus, int userId)
        {
            var result = dataAccess.SetOrderStatus(orderId, newStatus, userId);
            return Ok(result ? "updated" : "update fail");
        }
        [HttpGet("GetOrderByUser")]
        public IActionResult GetOrdersByUserId(int userId)
        {
            var result = dataAccess.GetOrdersByUserId(userId);
            return Ok(result);
        }
        [HttpGet("Getconfirm")]
        public IActionResult GetConfirmOder(int userId)
        {
            var result = dataAccess.GetConfirmOder(userId);
            return Ok(result);
        }
        [HttpDelete("DeleteOrder")]
        public IActionResult DeleteOrder(int orderId)
        {
            var result = dataAccess.DeleteOrder(orderId);
            return Ok(result ? "deleted" : "delete fail");
        }

        [HttpDelete("DeleteOrderByUser")]
        public IActionResult DeleteOrderByUser(int orderId)
        {
            var result = dataAccess.DeleteOrderByUser(orderId);
            return Ok(result ? "deleted" : "delete fail");
        }

        [HttpGet("GetOrderByStatus")]
        public IActionResult GetOrdersByStatus(int status)
        {
            var result = dataAccess.GetOrdersByStatus(status);
            return Ok(result);
        }
        [HttpGet("GetRevenue")]
        public IActionResult GetTotalAmountWithinPeriod(DateTime startDate, DateTime endDate)
        {
            var result = dataAccess.GetTotalAmountWithinPeriod(startDate, endDate);
            return Ok(result);
        }

        [HttpGet("GetProductSold")]
        public IActionResult GetTotalSoldProductsWithinPeriod(DateTime startDate, DateTime endDate)
        {
            var result = dataAccess.GetTotalSoldProductsWithinPeriod(startDate, endDate);
            return Ok(result);
        }
        [HttpGet("GetOderSold")]
        public IActionResult GetTotalSoldOrdersWithinPeriod(DateTime startDate, DateTime endDate)
        {
            var result = dataAccess.GetTotalSoldOrdersWithinPeriod(startDate, endDate);
            return Ok(result);
        }
        [HttpGet("GetTopUsers")]
        public IActionResult GetTop10UsersWithHighestSpending(DateTime startDate, DateTime endDate)
        {
            var result = dataAccess.GetTop10UsersWithHighestSpending(startDate, endDate);
            return Ok(result);
        }
    }
}
