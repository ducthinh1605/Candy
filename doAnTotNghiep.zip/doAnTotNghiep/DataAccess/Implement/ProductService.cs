﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;
using System.Data;
using System.Text.RegularExpressions;

namespace ECommerce.API.DataAccess
{
    public class ProductService : IProduct
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public ProductService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }

     
        public bool InsertProduct(UpdateProductReq Product)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                // Chèn vào bảng PRODUCT
                string insertProductQuery = "INSERT INTO PRODUCT (name, pakage, price, qty, img, description, expied, cate_id, sup_id, created_at, updated_at) " +
                                            "VALUES (@name, @package, @price, @qty, @img, @description, @expired, @categoryId, @supplierId, @createdAt, @updatedAt);";
                using (SqlCommand insertProductCommand = new SqlCommand(insertProductQuery, connection))
                {
                    insertProductCommand.Parameters.AddWithValue("@name", Product.name);
                    insertProductCommand.Parameters.AddWithValue("@package", Product.pakage);
                    insertProductCommand.Parameters.AddWithValue("@price", Product.price);
                    insertProductCommand.Parameters.AddWithValue("@qty", Product.qty);
                    insertProductCommand.Parameters.AddWithValue("@img", Product.img);
                    insertProductCommand.Parameters.AddWithValue("@description", Product.description);
                    insertProductCommand.Parameters.AddWithValue("@expired", Product.expied);
                    insertProductCommand.Parameters.AddWithValue("@categoryId", Product.cate_id);
                    insertProductCommand.Parameters.AddWithValue("@supplierId", Product.sup_id);
                    insertProductCommand.Parameters.AddWithValue("@createdAt", DateTime.Now);
                    insertProductCommand.Parameters.AddWithValue("@updatedAt", DateTime.Now);

                    insertProductCommand.ExecuteNonQuery();
                }

                // Lấy id của sản phẩm vừa chèn
                string getLastProductIdQuery = "SELECT @@IDENTITY";
                int lastProductId;
                using (SqlCommand getLastProductIdCommand = new SqlCommand(getLastProductIdQuery, connection))
                {
                    lastProductId = Convert.ToInt32(getLastProductIdCommand.ExecuteScalar());
                }

                // Chèn các hình ảnh con vào bảng PRODUCT_IMG
                if (Product.Images != null && Product.Images.Count > 0)
                {
                    foreach (var imageUrl in Product.Images)
                    {
                        string insertProductImgQuery = "INSERT INTO PRODUCT_IMG (img, created_at, updated_at, pro_id) VALUES (@imgUrl, @createdAt, @updatedAt, @productId);";
                        using (SqlCommand insertProductImgCommand = new SqlCommand(insertProductImgQuery, connection))
                        {
                            insertProductImgCommand.Parameters.AddWithValue("@imgUrl", imageUrl);
                            insertProductImgCommand.Parameters.AddWithValue("@createdAt", DateTime.Now);
                            insertProductImgCommand.Parameters.AddWithValue("@updatedAt", DateTime.Now);
                            insertProductImgCommand.Parameters.AddWithValue("@productId", lastProductId);

                            insertProductImgCommand.ExecuteNonQuery();
                        }
                    }
                }
            }

            return true;
        }





        public product GetProductById(int id)
        {
            var pro = new product();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;

                string query = "SELECT * FROM PRODUCT WHERE ID=" + id + ";";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    pro.id = (int)reader["id"];
                    pro.name = (string)reader["name"];
                    pro.pakage = (string)reader["pakage"];
                    pro.price = (int)reader["price"];
                    pro.qty = (int)reader["qty"];
                    pro.img = (string)reader["img"];
                    pro.description = (string)reader["description"];
                    pro.expired = (DateTime)reader["expied"];

                    // Lấy dữ liệu category và supplier dưới dạng ID
                    int categoryId = (int)reader["cate_id"];
                    int supplierId = (int)reader["sup_id"];

                    // Tạo đối tượng category và supplier chỉ với ID
                    pro.category = new cate { Id = categoryId };
                    pro.sup = new suplier { id = supplierId };

                    pro.Created_at = (DateTime)reader["created_at"];
                    pro.Updated_at = (DateTime)reader["updated_at"];
                }

                connection.Close();
            }

            return pro;
        }
        public List<product> GetProducts()
        {
            var prod = new List<product>();
            // Kết nối database
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM PRODUCT";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var pro = new product();
                    pro.id = (int)reader["id"];
                    pro.name = (string)reader["name"];
                    pro.pakage = (string)reader["pakage"];
                    pro.price = (int)reader["price"];
                    pro.qty = (int)reader["qty"];
                    pro.img = (string)reader["img"];
                    pro.description = (string)reader["description"];
                    pro.expired = (DateTime)reader["expied"];

                    // Lấy dữ liệu category và supplier dưới dạng ID
                    int categoryId = (int)reader["cate_id"];
                    int supplierId = (int)reader["sup_id"];

                    // Tạo đối tượng category và supplier chỉ với ID
                    pro.category = new cate { Id = categoryId };
                    pro.sup = new suplier { id = supplierId };

                    pro.Created_at = (DateTime)reader["created_at"];
                    pro.Updated_at = (DateTime)reader["updated_at"];
                    prod.Add(pro);
                }
            }
            return prod;
        }




        //public bool UpdateProduct(UpdateProductReq pro)
        //{
        //    using (SqlConnection connection = new SqlConnection(dbconnection))
        //    {
        //        SqlCommand command = new SqlCommand()
        //        {
        //            Connection = connection
        //        };

        //        string query = "SELECT COUNT(*) FROM PRODUCT WHERE id=@id;";
        //        command.CommandText = query;
        //        command.Parameters.Add("@id", SqlDbType.Int).Value = pro.id;

        //        connection.Open();
        //        int count = (int)command.ExecuteScalar();
        //        if (count == 0)
        //        {
        //            connection.Close();
        //            return false; // Không tìm thấy sản phẩm để cập nhật
        //        }

        //        query = "UPDATE PRODUCT SET name=@name, pakage=@pakage, price=@price, qty=@qty, img=@img, " +
        //                "description=@description, expied=@expired, cate_id=@cate_id, sup_id=@sup_id, " +
        //                "updated_at=@updated_at WHERE id=@id;";

        //        command.CommandText = query;
        //        command.Parameters.Add("@name", SqlDbType.NVarChar).Value = pro.name;
        //        command.Parameters.Add("@pakage", SqlDbType.NVarChar).Value = pro.pakage;
        //        command.Parameters.Add("@price", SqlDbType.Int).Value = pro.price;
        //        command.Parameters.Add("@qty", SqlDbType.Int).Value = pro.qty;
        //        command.Parameters.Add("@img", SqlDbType.NVarChar).Value = pro.img;
        //        command.Parameters.Add("@description", SqlDbType.NVarChar).Value = pro.description;
        //        command.Parameters.Add("@expired", System.Data.SqlDbType.DateTime).Value = pro.expied;
        //        command.Parameters.Add("@cate_id", SqlDbType.Int).Value = pro.cate_id;
        //        command.Parameters.Add("@sup_id", SqlDbType.Int).Value = pro.sup_id;
        //        command.Parameters.AddWithValue("@updated_at", DateTime.Now);

        //        command.ExecuteNonQuery();
        //        connection.Close();
        //    }

        //    return true; // Cập nhật thành công
        //}
        public bool UpdateProduct(UpdateProductReq Product)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                // Cập nhật thông tin trong bảng PRODUCT
                string updateProductQuery = "UPDATE PRODUCT SET name = @name, pakage = @package, price = @price, qty = @qty, img = @img, description = @description, expied = @expired, " +
                                            "cate_id = @categoryId, sup_id = @supplierId, updated_at = @updatedAt WHERE id = @productId;";
                using (SqlCommand updateProductCommand = new SqlCommand(updateProductQuery, connection))
                {
                    updateProductCommand.Parameters.AddWithValue("@productId", Product.id); // Assuming you have a property 'id' in your Product class
                    updateProductCommand.Parameters.AddWithValue("@name", Product.name);
                    updateProductCommand.Parameters.AddWithValue("@package", Product.pakage);
                    updateProductCommand.Parameters.AddWithValue("@price", Product.price);
                    updateProductCommand.Parameters.AddWithValue("@qty", Product.qty);
                    updateProductCommand.Parameters.AddWithValue("@img", Product.img);
                    updateProductCommand.Parameters.AddWithValue("@description", Product.description);
                    updateProductCommand.Parameters.AddWithValue("@expired", Product.expied);
                    updateProductCommand.Parameters.AddWithValue("@categoryId", Product.cate_id);
                    updateProductCommand.Parameters.AddWithValue("@supplierId", Product.sup_id);
                    updateProductCommand.Parameters.AddWithValue("@updatedAt", DateTime.Now);

                    updateProductCommand.ExecuteNonQuery();
                }

                // Xóa hình ảnh cũ của sản phẩm
                string deleteProductImgQuery = "DELETE FROM PRODUCT_IMG WHERE pro_id = @productId;";
                using (SqlCommand deleteProductImgCommand = new SqlCommand(deleteProductImgQuery, connection))
                {
                    deleteProductImgCommand.Parameters.AddWithValue("@productId", Product.id);
                    deleteProductImgCommand.ExecuteNonQuery();
                }

                // Chèn các hình ảnh mới vào bảng PRODUCT_IMG
                if (Product.Images != null && Product.Images.Count > 0)
                {
                    foreach (var imageUrl in Product.Images)
                    {
                        string insertProductImgQuery = "INSERT INTO PRODUCT_IMG (img, created_at, updated_at, pro_id) VALUES (@imgUrl, @createdAt, @updatedAt, @productId);";
                        using (SqlCommand insertProductImgCommand = new SqlCommand(insertProductImgQuery, connection))
                        {
                            insertProductImgCommand.Parameters.AddWithValue("@imgUrl", imageUrl);
                            insertProductImgCommand.Parameters.AddWithValue("@createdAt", DateTime.Now);
                            insertProductImgCommand.Parameters.AddWithValue("@updatedAt", DateTime.Now);
                            insertProductImgCommand.Parameters.AddWithValue("@productId", Product.id);

                            insertProductImgCommand.ExecuteNonQuery();
                        }
                    }
                }
            }

            return true;
        }


        public bool DeleteProduct(int productId)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                // Kiểm tra xem sản phẩm có tồn tại không
                string checkExistenceQuery = "SELECT COUNT(*) FROM PRODUCT WHERE id = @productId;";
                using (SqlCommand checkExistenceCommand = new SqlCommand(checkExistenceQuery, connection))
                {
                    checkExistenceCommand.Parameters.AddWithValue("@productId", productId);

                    int count = (int)checkExistenceCommand.ExecuteScalar();
                    if (count == 0)
                    {
                        // Đóng kết nối và trả về false nếu không tìm thấy sản phẩm để xóa
                        connection.Close();
                        return false;
                    }
                }

                // Xóa hình ảnh trong bảng PRODUCT_IMG
                string deleteProductImgQuery = "DELETE FROM PRODUCT_IMG WHERE pro_id = @productId;";
                using (SqlCommand deleteProductImgCommand = new SqlCommand(deleteProductImgQuery, connection))
                {
                    deleteProductImgCommand.Parameters.AddWithValue("@productId", productId);
                    deleteProductImgCommand.ExecuteNonQuery();
                }

                // Xóa sản phẩm trong bảng PRODUCT
                string deleteProductQuery = "DELETE FROM PRODUCT WHERE id = @productId;";
                using (SqlCommand deleteProductCommand = new SqlCommand(deleteProductQuery, connection))
                {
                    deleteProductCommand.Parameters.AddWithValue("@productId", productId);
                    deleteProductCommand.ExecuteNonQuery();
                }

                // Đóng kết nối sau khi xóa
                connection.Close();
            }

            return true; // Trả về true nếu xóa thành công
        }

        public int GetTotalOfPro()
        {
            var total = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open(); // Mở kết nối tại đây để đảm bảo kết nối được đóng sau khi hoàn tất công việc

                    SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM PRODUCT", connection);
                    total = (int)command.ExecuteScalar();
                }
            }
            catch (SqlException ex)
            {
                // Xử lý lỗi kết nối
                Console.WriteLine("Error connecting to the database: " + ex.Message);
                // Có thể thêm các xử lý khác tùy vào yêu cầu
            }

            return total;
        }

        public List<string> GetProductImagesById(int productId)
        {
            List<string> productImages = new List<string>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT img FROM PRODUCT_IMG WHERE pro_id = @productId";
                command.CommandText = query;
                command.Parameters.Add("@productId", SqlDbType.Int).Value = productId;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string image = (string)reader["img"];
                    productImages.Add(image);
                }

                connection.Close();
            }

            return productImages;
        }
        public List<product> GetProductsByCategory(string nameCategory, int count)
        {
            var prod = new List<product>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT TOP(@count) p.* FROM PRODUCT p INNER JOIN CATEGORY c ON p.cate_id = c.Id WHERE c.name = @nameCategory";
                command.CommandText = query;
                command.Parameters.AddWithValue("@count", count);
                command.Parameters.AddWithValue("@nameCategory", nameCategory);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    var pro = new product();
                    pro.id = (int)reader["id"];
                    pro.name = (string)reader["name"];
                    pro.pakage = (string)reader["pakage"];
                    pro.price = (int)reader["price"];
                    pro.qty = (int)reader["qty"];
                    pro.img = (string)reader["img"];
                    pro.description = (string)reader["description"];
                    pro.expired = (DateTime)reader["expied"];

                    // Lấy dữ liệu category và supplier dưới dạng ID
                    int categoryId = (int)reader["cate_id"];
                    int supplierId = (int)reader["sup_id"];

                    // Tạo đối tượng category và supplier chỉ với ID
                    pro.category = new cate { Id = categoryId };
                    pro.sup = new suplier { id = supplierId };

                    pro.Created_at = (DateTime)reader["created_at"];
                    pro.Updated_at = (DateTime)reader["updated_at"];
                    prod.Add(pro);
                }

                connection.Close();
            }

            return prod;
        }
        public List<product> GetProductsBySupplier(string nameSupplier, int count)
        {
            var prod = new List<product>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT TOP(@count) p.* FROM PRODUCT p INNER JOIN SUPPLIER s ON p.sup_id = s.Id WHERE s.name = @nameSupplier";
                command.CommandText = query;
                command.Parameters.AddWithValue("@count", count);
                command.Parameters.AddWithValue("@nameSupplier", nameSupplier);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    var pro = new product();
                    pro.id = (int)reader["id"];
                    pro.name = (string)reader["name"];
                    pro.pakage = (string)reader["pakage"];
                    pro.price = (int)reader["price"];
                    pro.qty = (int)reader["qty"];
                    pro.img = (string)reader["img"];
                    pro.description = (string)reader["description"];
                    pro.expired = (DateTime)reader["expied"];

                    // Lấy dữ liệu category và supplier dưới dạng ID
                    int categoryId = (int)reader["cate_id"];
                    int supplierId = (int)reader["sup_id"];

                    // Tạo đối tượng category và supplier chỉ với ID
                    pro.category = new cate { Id = categoryId };
                    pro.sup = new suplier { id = supplierId };

                    pro.Created_at = (DateTime)reader["created_at"];
                    pro.Updated_at = (DateTime)reader["updated_at"];
                    prod.Add(pro);
                }

                connection.Close();
            }

            return prod;
        }
        public product SearchProductsByName(string keyword)
        {
            var allProducts = GetProducts(); // Lấy tất cả sản phẩm

            // Chuẩn hóa từ khóa tìm kiếm (không phân biệt in hoa thường và không có dấu)
            string normalizedKeyword = RemoveAccents(keyword.ToLower());

            // Biến để lưu trữ sản phẩm phù hợp nhất
            product bestMatch = null;
            int lowestDistance = int.MaxValue; // Giá trị khoảng cách lớn nhất có thể

            foreach (var product in allProducts)
            {
                // Chuẩn hóa tên sản phẩm (không phân biệt in hoa thường và không có dấu)
                string normalizedProductName = RemoveAccents(product.name.ToLower());

                // Tính toán khoảng cách Levenshtein giữa từ khóa và tên sản phẩm chuẩn hóa
                int distance = ComputeLevenshteinDistance(normalizedProductName, normalizedKeyword);

                // Nếu khoảng cách nhỏ hơn khoảng cách thấp nhất hiện tại, cập nhật sản phẩm phù hợp nhất và khoảng cách thấp nhất
                if (distance < lowestDistance)
                {
                    bestMatch = product;
                    lowestDistance = distance;
                }
            }

            return bestMatch;
        }


        // Hàm tính toán khoảng cách Levenshtein giữa hai chuỗi
        public int ComputeLevenshteinDistance(string s, string t)
        {
            int[,] distance = new int[s.Length + 1, t.Length + 1];

            for (int i = 0; i <= s.Length; i++)
                distance[i, 0] = i;

            for (int j = 0; j <= t.Length; j++)
                distance[0, j] = j;

            for (int i = 1; i <= s.Length; i++)
            {
                for (int j = 1; j <= t.Length; j++)
                {
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;

                    distance[i, j] = Math.Min(
                        Math.Min(distance[i - 1, j] + 1, distance[i, j - 1] + 1),
                        distance[i - 1, j - 1] + cost
                    );
                }
            }

            return distance[s.Length, t.Length];
        }
        public string RemoveAccents(string text)
        {
            var normalizedString = text.Normalize(NormalizationForm.FormKD);
            var regex = new Regex(@"\p{IsCombiningDiacriticalMarks}+");
            return regex.Replace(normalizedString, string.Empty).Replace('đ', 'd').Replace('Đ', 'D');
        }

        public List<product> GetSimilarProductsByCategory(int productId)
        {
            int count = 10; // Số lượng sản phẩm bạn muốn lấy

            var similarProducts = new List<product>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string getCategoryQuery = "SELECT cate_id FROM PRODUCT WHERE id = @productId";
                command.CommandText = getCategoryQuery;
                command.Parameters.Add("@productId", SqlDbType.Int).Value = productId; // Thay thế AddWithValue

                connection.Open();
                int categoryId = 0;

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        categoryId = (int)reader["cate_id"];
                    }
                }

                // Lấy sản phẩm tương tự dựa trên danh mục
                string getSimilarProductsQuery = "SELECT TOP(@count) * FROM PRODUCT WHERE cate_id = @categoryId AND id != @productId";
                command.CommandText = getSimilarProductsQuery;
                command.Parameters.Clear(); // Xóa các tham số trước đó trước khi thêm mới
                command.Parameters.Add("@count", SqlDbType.Int).Value = count;
                command.Parameters.Add("@categoryId", SqlDbType.Int).Value = categoryId;
                command.Parameters.Add("@productId", SqlDbType.Int).Value = productId;

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var pro = new product();
                        pro.id = (int)reader["id"];
                        pro.name = (string)reader["name"];
                        pro.pakage = (string)reader["pakage"];
                        pro.price = (int)reader["price"];
                        pro.qty = (int)reader["qty"];
                        pro.img = (string)reader["img"];
                        pro.description = (string)reader["description"];
                        pro.expired = (DateTime)reader["expied"];
                        pro.category = new cate { Id = (int)reader["cate_id"] };
                        pro.sup = new suplier { id = (int)reader["sup_id"] };
                        pro.Created_at = (DateTime)reader["created_at"];
                        pro.Updated_at = (DateTime)reader["updated_at"];

                        similarProducts.Add(pro);
                    }
                }

                connection.Close();
            }

            return similarProducts;
        }

        public List<product> GetTopSellingProducts()
        {
            var topSellingProducts = new List<product>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                // Lấy top 10 sản phẩm bán chạy nhất từ các đơn hàng có status = 3
                string query = "SELECT TOP 10 pro_id, SUM(qty) as totalSold FROM ORDER_DETAILS " +
                               "INNER JOIN ORDERS ON ORDER_DETAILS.order_id = ORDERS.id " +
                               "WHERE ORDERS.status = 4 " +
                               "GROUP BY pro_id " +
                               "ORDER BY totalSold DESC";

                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    int productId = (int)reader["pro_id"];
                    int totalSold = (int)reader["totalSold"];

                    // Lấy thông tin sản phẩm từ productId
                    product productInfo = GetProductById(productId);

                    // Nếu sản phẩm tồn tại, thêm vào danh sách topSellingProducts
                    if (productInfo != null)
                    {
                        productInfo.qty = totalSold; // Số lượng bán được của sản phẩm

                        topSellingProducts.Add(productInfo);
                    }
                }

                connection.Close();
            }

            return topSellingProducts;
        }
        public List<product> GetLatestProducts()
        {
            var latestProducts = new List<product>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                // Lấy tất cả sản phẩm được sắp xếp theo thứ tự giảm dần của ngày tạo
                string query = "SELECT * FROM PRODUCT ORDER BY created_at DESC";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    var pro = new product();
                    pro.id = (int)reader["id"];
                    pro.name = (string)reader["name"];
                    pro.pakage = (string)reader["pakage"];
                    pro.price = (int)reader["price"];
                    pro.qty = (int)reader["qty"];
                    pro.img = (string)reader["img"];
                    pro.description = (string)reader["description"];
                    pro.expired = (DateTime)reader["expied"];
                    pro.category = new cate { Id = (int)reader["cate_id"] };
                    pro.sup = new suplier { id = (int)reader["sup_id"] };
                    pro.Created_at = (DateTime)reader["created_at"];
                    pro.Updated_at = (DateTime)reader["updated_at"];

                    latestProducts.Add(pro);
                }

                connection.Close();
            }

            return latestProducts;
        }
        public List<product> GetProductsByExpirationDescending()
        {
            var prod = new List<product>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                // Lấy tất cả sản phẩm được sắp xếp theo ngày hết hạn giảm dần
                string query = "SELECT * FROM PRODUCT ORDER BY expied ASC";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    var pro = new product();
                    pro.id = (int)reader["id"];
                    pro.name = (string)reader["name"];
                    pro.pakage = (string)reader["pakage"];
                    pro.price = (int)reader["price"];
                    pro.qty = (int)reader["qty"];
                    pro.img = (string)reader["img"];
                    pro.description = (string)reader["description"];
                    pro.expired = (DateTime)reader["expied"];
                    pro.category = new cate { Id = (int)reader["cate_id"] };
                    pro.sup = new suplier { id = (int)reader["sup_id"] };
                    pro.Created_at = (DateTime)reader["created_at"];
                    pro.Updated_at = (DateTime)reader["updated_at"];

                    prod.Add(pro);
                }

                connection.Close();
            }

            return prod;
        }



    }
}
