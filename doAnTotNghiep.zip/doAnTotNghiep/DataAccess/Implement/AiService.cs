﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace ECommerce.API.DataAccess
{
    public class AiService : IOpenAi
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey;
        private readonly string _apiBaseUri;

        public AiService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;

            // Đọc cấu hình từ appsettings.json hoặc biến môi trường
            _apiKey = configuration["OpenAI:ApiKey"];
            _apiBaseUri = configuration["OpenAI:ApiBaseUri"];

            // Cấu hình HttpClient
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_apiKey}");
            _httpClient.BaseAddress = new Uri(_apiBaseUri);
        }

        public async Task<string> GenerateTextAsync(string prompt)
        {
            var requestData = new
            {
                prompt = prompt,
                max_tokens = 300 // Tăng số lượng tokens nếu cần
            };

            string jsonContent = JsonConvert.SerializeObject(requestData);

            var response = await _httpClient.PostAsync("v1/engines/davinci/completions",
                new StringContent(jsonContent, Encoding.UTF8, "application/json"));

            response.EnsureSuccessStatusCode();

            var responseContent = await response.Content.ReadAsStringAsync();

            // Phân tích cú pháp JSON và trích xuất phần văn bản
            var jsonResponse = JsonConvert.DeserializeObject<dynamic>(responseContent);
            var textResponse = jsonResponse.choices[0].text.ToString();

            return textResponse;
        }

    }
}