﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;
using System.Data;

namespace ECommerce.API.DataAccess
{
    public class ProductIMGService:IProduct_IMG
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public ProductIMGService (IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }

        public bool InsertProduct_img(product_IMGReq product_img)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM PRODUCT_IMG WHERE id = @productIMGId;";
                command.CommandText = query;
                command.Parameters.Add("@productIMGId", System.Data.SqlDbType.NVarChar).Value = product_img.id;
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    connection.Close();
                    return false;
                }

                query = "INSERT INTO PRODUCT_IMG (img,created_at, updated_at, pro_id) " +
                        "VALUES (@img,@cre, @up, @pro_id);";

                command.CommandText = query;
                command.Parameters.Add("@img", System.Data.SqlDbType.NVarChar).Value = product_img.img;
                command.Parameters.AddWithValue("@cre", DateTime.Now);
                command.Parameters.AddWithValue("@up", DateTime.Now);
                command.Parameters.Add("@pro_id", System.Data.SqlDbType.Int).Value = product_img.proId;
                command.ExecuteNonQuery();
            }
            return true;
        }
        public List<product_IMG> GetProduct_img()
        {
            var prod_img = new List<product_IMG>();
            // Kết nối database
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM PRODUCT_IMG";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var pro_img = new product_IMG();
                    pro_img.id = (int)reader["id"];
                    pro_img.img = (string)reader["img"];

                    // Lấy dữ liệu category và supplier dưới dạng ID
                    int proId = (int)reader["pro_id"];

                    // Tạo đối tượng category và supplier chỉ với ID
                    pro_img.pro_id = new product { id = proId };
                    pro_img.Created_at = (DateTime)reader["created_at"];
                    pro_img.Updated_at = (DateTime)reader["updated_at"];
                    prod_img.Add(pro_img);
                }
            }
            return prod_img;
        }
        public product_IMG GetProduct_imgById(int id)
        {
            product_IMG prodImg = null;

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM PRODUCT_IMG WHERE id = @productImgId";
                command.CommandText = query;
                command.Parameters.Add("@productImgId", System.Data.SqlDbType.Int).Value = id;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    prodImg = new product_IMG();
                    prodImg.id = (int)reader["id"];
                    prodImg.img = (string)reader["img"];
                    prodImg.pro_id = new product { id = (int)reader["pro_id"] };
                    prodImg.Created_at = (DateTime)reader["created_at"];
                    prodImg.Updated_at = (DateTime)reader["updated_at"];
                }
            }

            return prodImg;
        }

        public List<product_IMG> GetProductImagesByProductId(int productId)
        {
            List<product_IMG> prodImages = new List<product_IMG>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM PRODUCT_IMG WHERE pro_id = @productId";
                command.CommandText = query;
                command.Parameters.Add("@productId", System.Data.SqlDbType.Int).Value = productId;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    product_IMG prodImg = new product_IMG();
                    prodImg.id = (int)reader["id"];
                    prodImg.img = (string)reader["img"];
                    prodImg.pro_id = new product { id = (int)reader["pro_id"] };
                    prodImg.Created_at = (DateTime)reader["created_at"];
                    prodImg.Updated_at = (DateTime)reader["updated_at"];

                    prodImages.Add(prodImg);
                }
            }

            return prodImages;
        }

        public bool UpdateProduct_img(product_IMGReq product_img)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT COUNT(*) FROM PRODUCT_IMG WHERE id=@id;";
                command.CommandText = query;
                command.Parameters.Add("@id", SqlDbType.Int).Value = product_img.id;

                connection.Open();
                int count = (int)command.ExecuteScalar();
                if (count == 0)
                {
                    connection.Close();
                    return false; // Không tìm thấy để cập nhật
                }

                query = "UPDATE PRODUCT_IMG SET img=@img, updated_at=@updated_at,pro_id=@pro_id WHERE id=@id;";

                command.CommandText = query;
                command.Parameters.Add("@img", SqlDbType.NVarChar).Value = product_img.img;
                command.Parameters.AddWithValue("@updated_at", DateTime.Now);
                command.Parameters.Add("@pro_id", SqlDbType.Int).Value = product_img.proId;
                command.ExecuteNonQuery();
                connection.Close();
            }
            return true; // Cập nhật thành công
        }
        public bool DeleteProduct_img(int id)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT COUNT(*) FROM PRODUCT_IMG WHERE id=@id;";
                command.CommandText = query;
                command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                connection.Open();
                int count = (int)command.ExecuteScalar();
                if (count == 0)
                {
                    connection.Close();
                    return false; // Không tìm thấy để xóa
                }

                query = "DELETE FROM PRODUCT_IMG WHERE id=@id;";

                command.CommandText = query;
                command.ExecuteNonQuery();
                connection.Close();
            }
            return true; // Xóa thành công
        }
        public int GetTotalOfProIMG()
        {
            var total = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open(); // Mở kết nối tại đây để đảm bảo kết nối được đóng sau khi hoàn tất công việc

                    SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM PRODUCT_IMG", connection);
                    total = (int)command.ExecuteScalar();
                }
            }
            catch (SqlException ex)
            {
                // Xử lý lỗi kết nối
                Console.WriteLine("Error connecting to the database: " + ex.Message);
                // Có thể thêm các xử lý khác tùy vào yêu cầu
            }

            return total;
        }
    }


}
