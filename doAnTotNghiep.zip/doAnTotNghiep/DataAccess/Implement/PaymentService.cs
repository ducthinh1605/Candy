﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;

namespace ECommerce.API.DataAccess
{
    public class PaymentService : Ipayment
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public PaymentService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }

        public bool InsertPayment(paymentMethod pay)
        {
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM PAYMENT_MENTHOD WHERE id='" + pay.Id + "';";
                command.CommandText = query;
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    connection.Close();
                    return false;
                }

                query = "INSERT INTO PAYMENT_MENTHOD ( id, paymentName, isavailable, created_at,updated_at) VALUES( @id,@name,@avl,@cre,@upd); ";

                command.CommandText = query;
                command.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = pay.Id;
                command.Parameters.Add("@name", System.Data.SqlDbType.NVarChar).Value = pay.paymentName;
                command.Parameters.Add("@avl", System.Data.SqlDbType.Int).Value = pay.isAvailable;
                command.Parameters.Add("@cre", System.Data.SqlDbType.DateTime).Value = pay.Created_at;
                command.Parameters.Add("@upd", System.Data.SqlDbType.DateTime).Value = pay.Updated_at;

                command.ExecuteNonQuery();
            }
            return true;
        }
        public paymentMethod GetPaymentById(int paymentId)
        {
            paymentMethod payment = null;

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                string getPaymentQuery = "SELECT * FROM PAYMENT_MENTHOD WHERE id = @paymentId";
                using (SqlCommand getPaymentCommand = new SqlCommand(getPaymentQuery, connection))
                {
                    getPaymentCommand.Parameters.AddWithValue("@paymentId", paymentId);

                    using (SqlDataReader reader = getPaymentCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            payment = new paymentMethod
                            {
                                Id = Convert.ToInt32(reader["id"]),
                                paymentName = reader["paymentName"].ToString(),
                                isAvailable = Convert.ToInt32(reader["isavailable"]),
                                Created_at = Convert.ToDateTime(reader["created_at"]),
                                Updated_at = Convert.ToDateTime(reader["updated_at"])
                            };
                        }
                    }
                }
            }

            return payment;
        }
    }
}