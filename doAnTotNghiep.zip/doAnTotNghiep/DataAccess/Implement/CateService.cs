﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Mail;

namespace ECommerce.API.DataAccess
{
    public class CateService : Icate
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public CateService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }

        public bool insertCate(cate category)
        {
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM CATEGORY WHERE id='" + category.Id + "';";
                command.CommandText = query;
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    connection.Close();
                    return false;
                }

                query = "INSERT INTO CATEGORY ( name,created_at,updated_at) VALUES( @n,@cre,@up); ";

                command.CommandText = query;
                command.Parameters.Add("@n", System.Data.SqlDbType.NVarChar).Value = category.Name;
                command.Parameters.AddWithValue("@cre", DateTime.Now);
                command.Parameters.AddWithValue("@up", DateTime.Now);

                command.ExecuteNonQuery();
            }
            return true;
        }
        public List<cate> GetCate()
        {
            List<cate> categories = new List<cate>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM CATEGORY";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cate category = new cate();
                    category.Id = (int)reader["id"];
                    category.Name = (string)reader["name"];
                    category.Created_at = (DateTime)reader["created_at"];
                    category.Updated_at = (DateTime)reader["updated_at"];

                    categories.Add(category);
                }
            }

            return categories;
        }
        public cate GetCateById(int id)
        {
            cate category = null;

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM CATEGORY WHERE id=@id";
                command.CommandText = query;
                command.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = id;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    category = new cate();
                    category.Id = (int)reader["id"];
                    category.Name = (string)reader["name"];
                    category.Created_at = (DateTime)reader["created_at"];
                    category.Updated_at = (DateTime)reader["updated_at"];
                }
            }

            return category;
        }

        public bool UpdateCate(cate category)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT COUNT(*) FROM CATEGORY WHERE id=@id";
                command.CommandText = query;
                command.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = category.Id;

                connection.Open();
                int count = (int)command.ExecuteScalar();
                if (count == 0)
                {
                    connection.Close();
                    return false; // Không tìm thấy danh mục để cập nhật
                }

                query = "UPDATE CATEGORY SET name=@name, updated_at=@up WHERE id=@id";
                command.CommandText = query;
                command.Parameters.Add("@name", System.Data.SqlDbType.NVarChar).Value = category.Name;
                command.Parameters.AddWithValue("@up", DateTime.Now);

                command.ExecuteNonQuery();
                connection.Close();
            }

            return true; // Cập nhật thành công
        }
        public bool DeleteCate(int id)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT COUNT(*) FROM CATEGORY WHERE id=@id";
                command.CommandText = query;
                command.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = id;

                connection.Open();
                int count = (int)command.ExecuteScalar();
                if (count == 0)
                {
                    connection.Close();
                    return false; // Không tìm thấy danh mục để xóa
                }

                query = "DELETE FROM CATEGORY WHERE id=@id";
                command.CommandText = query;

                command.ExecuteNonQuery();
                connection.Close();
            }

            return true; // Xóa thành công
        }
        public int GetTotalOfCate()
        {
            var totalUsers = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open(); // Mở kết nối tại đây để đảm bảo kết nối được đóng sau khi hoàn tất công việc

                    SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Category", connection);
                    totalUsers = (int)command.ExecuteScalar();
                }
            }
            catch (SqlException ex)
            {
                // Xử lý lỗi kết nối
                Console.WriteLine("Error connecting to the database: " + ex.Message);
                // Có thể thêm các xử lý khác tùy vào yêu cầu
            }

            return totalUsers;
        }


    }
}
