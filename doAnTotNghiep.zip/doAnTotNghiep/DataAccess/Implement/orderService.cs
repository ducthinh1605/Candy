﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Newtonsoft.Json;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;
using System.Net.Mail;

namespace ECommerce.API.DataAccess
{
    public class orderService : IOrder
    {
        private readonly IConfiguration configuration;
        private readonly IUserService userService;
        private readonly Ipayment paymentService;
        private readonly IAdmin adminService;
        private readonly string dbconnection;

        public orderService(IConfiguration configuration, IUserService userService, Ipayment paymentService, IAdmin adminService)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
            this.userService = userService;
            this.paymentService = paymentService;
            this.adminService = adminService;
        }

        public List<orders> GetOrdersById(int id)
        {
            List<orders> ordersList = new List<orders>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    SqlCommand command = new SqlCommand
                    {
                        Connection = connection
                    };

                    string query = "SELECT * FROM ORDERS ord" +
                                   " INNER JOIN ADMINS ad ON ord.admin_id = ad.id" +
                                   " INNER JOIN USERS u ON ord.users_id = u.id" +
                                   " INNER JOIN PAYMENT_MENTHOD pay ON ord.pm_id = pay.id" +
                                   " WHERE ord.id = @orderId";

                    command.CommandText = query;
                    command.Parameters.AddWithValue("@orderId", id);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var order = new orders
                        {
                            Id = (int)reader["id"],
                            OrderName = (string)reader["order_name"],
                            OrderPhone = (int)reader["order_phone"],
                            OrderCity = (string)reader["order_city"],
                            OrderDistrict = (string)reader["order_district"],
                            OrderWard = (string)reader["order_ward"],
                            OrderStreet = (string)reader["order_street"],
                            Note = (string)reader["note"],
                            status = (int)reader["status"],
                            total = (int)reader["total"],
                            CreatedAt = (DateTime)reader["created_at"],
                            UpdatedAt = (DateTime)reader["updated_at"], // Fixed to updated_at
                            UsersId = userService.GetUser((int)reader["users_id"]),
                            AdminId = adminService.GetAdminById((int)reader["admin_id"]),
                            PmId = paymentService.GetPaymentById((int)reader["pm_id"])
                        };

                        ordersList.Add(order);
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                // Handle exception if an error occurs
            }

            return ordersList;
        }


        public int GetTotalOrders()
        {
            int totalOrders = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    SqlCommand command = new SqlCommand
                    {
                        Connection = connection
                    };

                    string query = "SELECT COUNT(*) AS TotalOrders FROM ORDERS";

                    command.CommandText = query;

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        totalOrders = (int)reader["TotalOrders"];
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                // Handle exception
            }

            return totalOrders;
        }
        //public Dictionary<string, int> GetTotalAmountByMonth()
        //{
        //    try
        //    {
        //        Dictionary<string, int> monthlyTotalAmount = new Dictionary<string, int>();
        //        var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository
        //        var currentDate = DateTime.Now;

        //        foreach (var order in orders)
        //        {
        //            if (order.status == 4) // Kiểm tra trạng thái của đơn hàng là giao thành công
        //            {
        //                TimeSpan timeSpan = currentDate - order.CreatedAt;
        //                if (timeSpan.Days <= 30) // Kiểm tra đơn hàng được tạo trong vòng 30 ngày
        //                {
        //                    string monthYear = order.CreatedAt.ToString("MM/yyyy");
        //                    if (monthlyTotalAmount.ContainsKey(monthYear))
        //                    {
        //                        monthlyTotalAmount[monthYear] += order.total;
        //                    }
        //                    else
        //                    {
        //                        monthlyTotalAmount.Add(monthYear, order.total);
        //                    }
        //                }
        //            }
        //        }

        //        return monthlyTotalAmount;
        //    }
        //    catch (Exception ex)
        //    {
        //        // Xử lý ngoại lệ nếu có
        //        return null;
        //    }
        //}

        //public Dictionary<string, int> GetTotalAmountByQuarter()
        //{
        //    try
        //    {
        //        Dictionary<string, int> quarterlyTotalAmount = new Dictionary<string, int>();
        //        var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository

        //        foreach (var order in orders)
        //        {
        //            if (order.status == 4) // Kiểm tra trạng thái của đơn hàng là giao thành công
        //            {
        //                string quarterYear = "Q" + ((order.CreatedAt.Month - 1) / 3 + 1) + "/" + order.CreatedAt.Year;
        //                if (quarterlyTotalAmount.ContainsKey(quarterYear))
        //                {
        //                    quarterlyTotalAmount[quarterYear] += order.total;
        //                }
        //                else
        //                {
        //                    quarterlyTotalAmount.Add(quarterYear, order.total);
        //                }
        //            }
        //        }

        //        return quarterlyTotalAmount;
        //    }
        //    catch (Exception ex)
        //    {
        //        // Xử lý ngoại lệ nếu có
        //        return null;
        //    }
        //}
        //public Dictionary<string, int> GetTotalAmountByYear()
        //{
        //    try
        //    {
        //        Dictionary<string, int> yearlyTotalAmount = new Dictionary<string, int>();
        //        var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository

        //        foreach (var order in orders)
        //        {
        //            if (order.status == 4) // Kiểm tra trạng thái của đơn hàng là giao thành công
        //            {
        //                string year = order.CreatedAt.Year.ToString();
        //                if (yearlyTotalAmount.ContainsKey(year))
        //                {
        //                    yearlyTotalAmount[year] += order.total;
        //                }
        //                else
        //                {
        //                    yearlyTotalAmount.Add(year, order.total);
        //                }
        //            }
        //        }

        //        return yearlyTotalAmount;
        //    }
        //    catch (Exception ex)
        //    {
        //        // Xử lý ngoại lệ nếu có
        //        return null;
        //    }
        //}

        public List<orders> GetOrders()
        {
            var Order = new List<orders>();
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM ORDERS ord, USERS u, PAYMENT_MENTHOD pay" +
                    " WHERE ord.pm_id=pay.id AND ord.users_id=u.id";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var orders = new orders()
                    {
                        Id = (int)reader["id"],
                        OrderName = (string)reader["order_name"],
                        OrderPhone = (int)reader["order_phone"],
                        OrderCity = (string)reader["order_city"],
                        OrderDistrict = (string)reader["order_district"],
                        OrderWard = (string)reader["order_ward"],
                        OrderStreet = (string)reader["order_street"],
                        Note = (string)reader["note"],
                        total = (int)reader["total"],
                        status = (int)reader["status"],
                        CreatedAt = (DateTime)reader["created_at"],
                        UpdatedAt = (DateTime)reader["created_at"],

                        UsersId = new User()
                        {
                            Id = (int)reader["users_id"],
                            Name = (string)reader["name"],
                            Account = (string)reader["account"],
                            Email = (string)reader["email"],
                            Phone = (int)reader["phone"],

                        },

                        PmId = new paymentMethod()
                        {
                            Id = (int)reader["pm_id"],
                            paymentName = (string)reader["paymentName"]
                        }
                    };

                    Order.Add(orders);
                }
                connection.Close();
            }
            return Order;
        }

        public bool SetOrderStatus(int orderId, int newStatus, int userId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    // Check the existence of the order and user before updating the status
                    string checkExistQuery = "SELECT COUNT(*) FROM ORDERS WHERE id = @orderId AND users_id = @userId";
                    using (SqlCommand checkExistCommand = new SqlCommand(checkExistQuery, connection))
                    {
                        checkExistCommand.Parameters.AddWithValue("@orderId", orderId);
                        checkExistCommand.Parameters.AddWithValue("@userId", userId);

                        int count = (int)checkExistCommand.ExecuteScalar();
                        if (count == 0)
                        {
                            return false; // Return false if the order doesn't exist for the user
                        }
                    }

                    // Update the status of the order for the specific user
                    string updateStatusQuery = "UPDATE ORDERS SET status = @newStatus WHERE id = @orderId AND users_id = @userId";
                    using (SqlCommand updateStatusCommand = new SqlCommand(updateStatusQuery, connection))
                    {
                        updateStatusCommand.Parameters.AddWithValue("@newStatus", newStatus);
                        updateStatusCommand.Parameters.AddWithValue("@orderId", orderId);
                        updateStatusCommand.Parameters.AddWithValue("@userId", userId);

                        int affectedRows = updateStatusCommand.ExecuteNonQuery();

                        return affectedRows > 0; // Return true if the update is successful
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions if an error occurs during execution
                return false;
            }
        }
        public List<orders> GetOrdersByUserId(int userId)
        {
            var userOrders = new List<orders>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    SqlCommand command = new SqlCommand
                    {
                        Connection = connection
                    };

                    string query = "SELECT * FROM ORDERS WHERE users_id = @userId AND status <> 4";
                    command.CommandText = query;
                    command.Parameters.AddWithValue("@userId", userId);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var order = new orders()
                        {
                            Id = (int)reader["id"],
                            OrderName = (string)reader["order_name"],
                            OrderPhone = (int)reader["order_phone"],
                            OrderCity = (string)reader["order_city"],
                            OrderDistrict = (string)reader["order_district"],
                            OrderWard = (string)reader["order_ward"],
                            OrderStreet = (string)reader["order_street"],
                            Note = (string)reader["note"],
                            status = (int)reader["status"],
                            total = (int)reader["total"],
                            CreatedAt = (DateTime)reader["created_at"],
                            UpdatedAt = (DateTime)reader["created_at"],
                            UsersId = userService.GetUser((int)reader["users_id"]),
                            AdminId = adminService.GetAdminById((int)reader["admin_id"]),
                            PmId = paymentService.GetPaymentById((int)reader["pm_id"])
                        };

                        userOrders.Add(order);
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions if an error occurs
            }

            return userOrders;
        }
        public List<orders> GetConfirmOder(int userId)
        {
            var userOrders = new List<orders>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    SqlCommand command = new SqlCommand
                    {
                        Connection = connection
                    };

                    string query = "SELECT * FROM ORDERS WHERE users_id = @userId AND status = 4";
                    command.CommandText = query;
                    command.Parameters.AddWithValue("@userId", userId);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var order = new orders()
                        {
                            Id = (int)reader["id"],
                            OrderName = (string)reader["order_name"],
                            OrderPhone = (int)reader["order_phone"],
                            OrderCity = (string)reader["order_city"],
                            OrderDistrict = (string)reader["order_district"],
                            OrderWard = (string)reader["order_ward"],
                            OrderStreet = (string)reader["order_street"],
                            Note = (string)reader["note"],
                            status = (int)reader["status"],
                            total = (int)reader["total"],
                            CreatedAt = (DateTime)reader["created_at"],
                            UpdatedAt = (DateTime)reader["created_at"],
                            UsersId = userService.GetUser((int)reader["users_id"]),
                            AdminId = adminService.GetAdminById((int)reader["admin_id"]),
                            PmId = paymentService.GetPaymentById((int)reader["pm_id"])
                        };

                        userOrders.Add(order);
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions if an error occurs
            }

            return userOrders;
        }

        public List<orders> GetOrdersByStatus(int status)
        {
            var ordersByStatus = new List<orders>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    SqlCommand command = new SqlCommand
                    {
                        Connection = connection
                    };

                    string query = "SELECT * FROM ORDERS WHERE status = @status";
                    command.CommandText = query;
                    command.Parameters.AddWithValue("@status", status);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var order = new orders()
                        {
                            Id = (int)reader["id"],
                            OrderName = (string)reader["order_name"],
                            OrderPhone = (int)reader["order_phone"],
                            OrderCity = (string)reader["order_city"],
                            OrderDistrict = (string)reader["order_district"],
                            OrderWard = (string)reader["order_ward"],
                            OrderStreet = (string)reader["order_street"],
                            Note = (string)reader["note"],
                            status = (int)reader["status"],
                            total = (int)reader["total"],
                            CreatedAt = (DateTime)reader["created_at"],
                            UpdatedAt = (DateTime)reader["created_at"],
                            UsersId = userService.GetUser((int)reader["users_id"]),
                            AdminId = adminService.GetAdminById((int)reader["admin_id"]),
                            PmId = paymentService.GetPaymentById((int)reader["pm_id"])
                        };

                        ordersByStatus.Add(order);
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ nếu có lỗi xảy ra
            }

            return ordersByStatus;
        }

        public bool DeleteOrder(int orderId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    // Bắt đầu một giao dịch để đảm bảo tính nhất quán
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        string updateProductQuantitiesQuery = "UPDATE PRODUCT " +
                            "SET qty = qty + (SELECT qty FROM ORDER_DETAILS WHERE order_id = @orderId AND PRODUCT.id = ORDER_DETAILS.pro_id) " +
                            "WHERE EXISTS (SELECT 1 FROM ORDER_DETAILS WHERE order_id = @orderId AND PRODUCT.id = ORDER_DETAILS.pro_id)";

                        // Cập nhật số lượng sản phẩm
                        using (SqlCommand updateProductQuantitiesCommand = new SqlCommand(updateProductQuantitiesQuery, connection, transaction))
                        {
                            updateProductQuantitiesCommand.Parameters.AddWithValue("@orderId", orderId);
                            int affectedRowsInProducts = updateProductQuantitiesCommand.ExecuteNonQuery();

                            // Nếu số lượng sản phẩm được cập nhật thành công
                            if (affectedRowsInProducts > 0)
                            {
                                string deleteOrderDetailsQuery = "DELETE FROM ORDER_DETAILS WHERE order_id = @orderId";

                                // Xóa chi tiết đơn hàng
                                using (SqlCommand deleteOrderDetailsCommand = new SqlCommand(deleteOrderDetailsQuery, connection, transaction))
                                {
                                    deleteOrderDetailsCommand.Parameters.AddWithValue("@orderId", orderId);
                                    int affectedRowsInDetails = deleteOrderDetailsCommand.ExecuteNonQuery();

                                    if (affectedRowsInDetails > 0)
                                    {
                                        string deleteOrderQuery = "DELETE FROM ORDERS WHERE id = @orderId";

                                        // Xóa đơn hàng
                                        using (SqlCommand deleteOrderCommand = new SqlCommand(deleteOrderQuery, connection, transaction))
                                        {
                                            deleteOrderCommand.Parameters.AddWithValue("@orderId", orderId);
                                            int affectedRowsInOrder = deleteOrderCommand.ExecuteNonQuery();

                                            // Nếu xóa đơn hàng thành công, commit giao dịch
                                            if (affectedRowsInOrder > 0)
                                            {
                                                transaction.Commit();
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // Nếu có lỗi, rollback giao dịch
                        transaction.Rollback();
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                // Log lỗi hoặc xử lý lỗi tại đây
                return false;
            }

            return false;
        }
        public bool DeleteOrderByUser(int orderId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    // Lấy trạng thái của đơn hàng
                    string getStatusQuery = "SELECT status FROM ORDERS WHERE id = @orderId";
                    using (SqlCommand getStatusCommand = new SqlCommand(getStatusQuery, connection))
                    {
                        getStatusCommand.Parameters.AddWithValue("@orderId", orderId);
                        int status = (int)getStatusCommand.ExecuteScalar();

                        // Kiểm tra trạng thái
                        if (status < 2)
                        {
                            using (SqlTransaction transaction = connection.BeginTransaction())
                            {
                                // Tiến hành xóa
                                string updateProductQuantitiesQuery = "UPDATE PRODUCT " +
                                    "SET qty = qty + (SELECT qty FROM ORDER_DETAILS WHERE order_id = @orderId AND PRODUCT.id = ORDER_DETAILS.pro_id) " +
                                    "WHERE EXISTS (SELECT 1 FROM ORDER_DETAILS WHERE order_id = @orderId AND PRODUCT.id = ORDER_DETAILS.pro_id)";

                                using (SqlCommand updateProductQuantitiesCommand = new SqlCommand(updateProductQuantitiesQuery, connection, transaction))
                                {
                                    updateProductQuantitiesCommand.Parameters.AddWithValue("@orderId", orderId);
                                    int affectedRowsInProducts = updateProductQuantitiesCommand.ExecuteNonQuery();

                                    if (affectedRowsInProducts > 0)
                                    {
                                        string deleteOrderDetailsQuery = "DELETE FROM ORDER_DETAILS WHERE order_id = @orderId";

                                        using (SqlCommand deleteOrderDetailsCommand = new SqlCommand(deleteOrderDetailsQuery, connection, transaction))
                                        {
                                            deleteOrderDetailsCommand.Parameters.AddWithValue("@orderId", orderId);
                                            int affectedRowsInDetails = deleteOrderDetailsCommand.ExecuteNonQuery();

                                            if (affectedRowsInDetails > 0)
                                            {
                                                string deleteOrderQuery = "DELETE FROM ORDERS WHERE id = @orderId";

                                                using (SqlCommand deleteOrderCommand = new SqlCommand(deleteOrderQuery, connection, transaction))
                                                {
                                                    deleteOrderCommand.Parameters.AddWithValue("@orderId", orderId);
                                                    int affectedRowsInOrder = deleteOrderCommand.ExecuteNonQuery();

                                                    if (affectedRowsInOrder > 0)
                                                    {
                                                        transaction.Commit();
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                transaction.Rollback();
                                return false;
                            }
                        }
                        else
                        {
                            // Trạng thái không hợp lệ để xóa
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log lỗi hoặc xử lý lỗi tại đây
                return false;
            }

            return false;
        }
        //public Dictionary<string, int> GetTotalAmountWithinPeriod(DateTime startDate, DateTime endDate)
        //{
        //    try
        //    {
        //        // Kiểm tra xem ngày bắt đầu và ngày kết thúc có hợp lệ không
        //        if (startDate > endDate)
        //        {
        //            throw new ArgumentException("Ngày bắt đầu không được lớn hơn ngày kết thúc.");
        //        }
        //        //if (endDate > DateTime.Now)
        //        //{
        //        //    throw new ArgumentException("Ngày kết thúc không được lớn hơn ngày hiện tại.");
        //        //}

        //        Dictionary<string, int> monthlyTotalAmount = new Dictionary<string, int>();
        //        var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository

        //        foreach (var order in orders)
        //        {
        //            if (order.status == 4 && order.CreatedAt >= startDate && order.CreatedAt <= endDate) // Kiểm tra trạng thái và ngày tạo của đơn hàng
        //            {
        //                string monthYear = order.CreatedAt.ToString("MM/yyyy");
        //                if (monthlyTotalAmount.ContainsKey(monthYear))
        //                {
        //                    monthlyTotalAmount[monthYear] += order.total;
        //                }
        //                else
        //                {
        //                    monthlyTotalAmount.Add(monthYear, order.total);
        //                }
        //            }
        //        }
        //        return monthlyTotalAmount;
        //    }
        //    catch (Exception ex)
        //    {
        //        // Xử lý ngoại lệ nếu có
        //        return null; // Hoặc trả về thông tin chi tiết của lỗi
        //    }
        //}
        public int GetTotalAmountWithinPeriod(DateTime startDate, DateTime endDate)
        {
            try
            {
                // Kiểm tra xem ngày bắt đầu và ngày kết thúc có hợp lệ không
                if (startDate > endDate)
                {
                    return 1;
                }
                if (endDate > DateTime.Now)
                {
                    return 1;
                }

                int totalAmount = 0;
                var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository

                foreach (var order in orders)
                {
                    if (order.status == 4 && order.CreatedAt >= startDate && order.CreatedAt <= endDate) // Kiểm tra trạng thái và ngày tạo của đơn hàng
                    {
                        totalAmount += order.total;
                    }
                }
                return totalAmount;
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ nếu có
                return 0; // Hoặc trả về giá trị mặc định hoặc thông tin chi tiết của lỗi
            }
        }
        public int GetTotalSoldProductsWithinPeriod(DateTime startDate, DateTime endDate)
        {
            try
            {
                // Kiểm tra xem ngày bắt đầu và ngày kết thúc có hợp lệ không
                if (startDate > endDate)
                {
                    throw new ArgumentException("Ngày bắt đầu không được lớn hơn ngày kết thúc.");
                }

                int totalSoldProducts = 0;
                var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository

                foreach (var order in orders)
                {
                    if (order.status == 4 && order.CreatedAt >= startDate && order.CreatedAt <= endDate)
                    {
                        // Kiểm tra trạng thái và ngày tạo của đơn hàng

                        // Lấy chi tiết đơn hàng từ ORDER_DETAILS
                        var orderDetails = GetOrderDetails(order.Id);

                        foreach (var orderDetail in orderDetails)
                        {
                            // Lặp qua tất cả các chi tiết đơn hàng và cộng dồn vào tổng số sản phẩm đã bán
                            totalSoldProducts += orderDetail.qty;
                        }
                    }
                }
                return totalSoldProducts;
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ nếu có
                return 0; // Hoặc trả về giá trị mặc định hoặc thông tin chi tiết của lỗi
            }
        }
        public User GetUser(int id)
        {
            var user = new User();
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM Users WHERE ID=" + id + ";";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    user.Id = (int)reader["ID"];
                    user.Name = (string)reader["Name"];
                    user.Email = (string)reader["Email"];
                    user.Account = (string)reader["Account"];
                    user.Password = (string)reader["Password"];
                    user.Phone = (int)reader["Phone"];
                    user.Created_at = (DateTime)reader["Created_at"];
                    user.Updated_at = (DateTime)reader["Updated_at"];
                }
            }
            return user;
        }
        public List<orderDetails> GetOrderDetails(int orderId)
        {
            var orderDetailsList = new List<orderDetails>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    string query = " SELECT * " +
                                    " FROM ORDER_DETAILS od " +
                                    " INNER JOIN PRODUCT p ON od.pro_id = p.id " +
                                    " INNER JOIN ORDERS o ON od.order_id = o.id " +
                                    " WHERE od.order_id = @OrderId ";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@OrderId", orderId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var orderDetails = new orderDetails()
                                {
                                    pro_id = new product()
                                    {
                                        id = (int)reader["id"],
                                        name = (string)reader["name"],
                                        price = (int)reader["price"],
                                        img = (string)reader["img"]

                                    },
                                    order_id = new orders()
                                    {
                                        Id = (int)reader["id"],
                                        OrderName = (string)reader["order_name"],
                                        OrderPhone = (int)reader["order_phone"],
                                        OrderCity = (string)reader["order_city"],
                                        OrderDistrict = (string)reader["order_district"],
                                        OrderWard = (string)reader["order_ward"],
                                        OrderStreet = (string)reader["order_street"],
                                        Note = (string)reader["note"],
                                        status = (int)reader["status"],
                                        total = (int)reader["total"],


                                    },
                                    qty = (int)reader["qty"],
                                    discount_price = (int)reader["discount_price"],
                                    total_price = (int)reader["total_price"],
                                    CreatedAt = (DateTime)reader["created_at"],
                                    UpdatedAt = (DateTime)reader["updated_at"],
                                };

                                orderDetailsList.Add(orderDetails);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            return orderDetailsList;
        }
        public int GetTotalSoldOrdersWithinPeriod(DateTime startDate, DateTime endDate)
        {
            try
            {
                // Kiểm tra xem ngày bắt đầu và ngày kết thúc có hợp lệ không
                if (startDate > endDate)
                {
                    throw new ArgumentException("Ngày bắt đầu không được lớn hơn ngày kết thúc.");
                }

                int totalSoldOrders = 0;
                var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository

                foreach (var order in orders)
                {
                    if (order.status == 4 && order.CreatedAt >= startDate && order.CreatedAt <= endDate)
                    {
                        // Kiểm tra trạng thái và ngày tạo của đơn hàng
                        totalSoldOrders++;
                    }
                }
                return totalSoldOrders;
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ nếu có
                return 0; // Hoặc trả về giá trị mặc định hoặc thông tin chi tiết của lỗi
            }
        }
        public List<UserSpendingInfo> GetTop10UsersWithHighestSpending(DateTime startDate, DateTime endDate)
        {
            try
            {
                // Kiểm tra xem ngày bắt đầu và ngày kết thúc có hợp lệ không
                if (startDate > endDate)
                {
                    throw new ArgumentException("Ngày bắt đầu không được lớn hơn ngày kết thúc.");
                }

                var userSpendingInfoList = new List<UserSpendingInfo>();
                var orders = GetOrders(); // Lấy tất cả đơn hàng từ repository

                foreach (var order in orders)
                {
                    if (order.status == 4 && order.CreatedAt >= startDate && order.CreatedAt <= endDate)
                    {
                        // Kiểm tra trạng thái và ngày tạo của đơn hàng
                        var userId = order.UsersId; // Giả sử có một thuộc tính UsersId trong đơn hàng để biểu diễn người dùng thực hiện đơn hàng
                        var totalOrderAmount = order.total;

                        // Kiểm tra xem đã tồn tại thông tin chi tiêu cho người dùng hay chưa
                        var existingUserSpendingInfo = userSpendingInfoList.FirstOrDefault(u => u.UserId == userId.Id);
                        if (existingUserSpendingInfo != null)
                        {
                            existingUserSpendingInfo.TotalSpending += totalOrderAmount;
                            existingUserSpendingInfo.TotalOrders++;
                        }
                        else
                        {
                            // Sử dụng hàm GetUser để lấy thông tin người dùng từ cơ sở dữ liệu
                            var user = GetUser(userId.Id);
                            if (user != null)
                            {
                                userSpendingInfoList.Add(new UserSpendingInfo
                                {
                                    UserId = user.Id,
                                    TotalSpending = totalOrderAmount,
                                    TotalOrders = 1,
                                    UserName = user.Name,
                                    UserEmail = user.Email
                                });
                            }
                        }
                    }
                }

                // Sắp xếp danh sách theo chi tiêu giảm dần
                userSpendingInfoList = userSpendingInfoList.OrderByDescending(u => u.TotalSpending).ToList();

                // Lấy ra 10 người dùng có chi tiêu cao nhất
                var top10Users = userSpendingInfoList.Take(10).ToList();

                return top10Users;
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ nếu có
                // Bạn có thể log ngoại lệ hoặc thực hiện xử lý khác tùy thuộc vào yêu cầu của bạn
                return new List<UserSpendingInfo>();
            }
        }
    }
    public class UserSpendingInfo
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public int TotalSpending { get; set; }
        public int TotalOrders { get; set; }
    }
}
