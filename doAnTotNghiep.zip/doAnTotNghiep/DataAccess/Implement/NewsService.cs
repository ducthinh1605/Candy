﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Newtonsoft.Json;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;

namespace ECommerce.API.DataAccess
{
    public class NewsService : Inews
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public NewsService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }
        public bool insertNews(newsReq newreq)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM NEWS WHERE id = @id;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@id", newreq.Id);
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    connection.Close();
                    return false;
                }

                query = "INSERT INTO NEWS (tittle, content, img, created_at,updated_at, ad_id) " +
                        "VALUES (@n, @em, @ac, @cre, @upd, @ad);";

                command.CommandText = query;
                command.Parameters.AddWithValue("@n", newreq.Title);
                command.Parameters.AddWithValue("@em", newreq.Content);
                command.Parameters.AddWithValue("@ac", newreq.Img);
                command.Parameters.AddWithValue("@cre", DateTime.Now);
                command.Parameters.AddWithValue("@upd", DateTime.Now);
                command.Parameters.AddWithValue("@ad", 1);
                command.ExecuteNonQuery();
            }
            return true;
        }
        public bool updateNews(newsReq newreq)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM NEWS WHERE ID = @newsId;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@newsId", newreq.Id);
                int count = (int)command.ExecuteScalar();

                if (count == 0)
                {
                    connection.Close();
                    return false;
                }

                query = "UPDATE NEWS " +
                        "SET tittle = @tit, content = @cont, img = @img, created_at = @cre, updated_at = @upd, ad_id = @ad " +
                        "WHERE ID = @newsId;";

                command.CommandText = query;
                command.Parameters.AddWithValue("@tit", newreq.Title);
                command.Parameters.AddWithValue("@cont", newreq.Content);
                command.Parameters.AddWithValue("@img", newreq.Img);
                command.Parameters.AddWithValue("@cre", DateTime.Now);
                command.Parameters.AddWithValue("@upd", DateTime.Now);
                command.Parameters.AddWithValue("@ad", 1);

                command.ExecuteNonQuery();
            }
            return true;
        }
        public List<news> GetAllNews()
        {
            var news = new List<news>();
            //ket noi database
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM NEWS";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var newsp = new news();
                    newsp.Id = (int)reader["id"];
                    newsp.Title = (string)reader["tittle"];
                    newsp.Content = (string)reader["content"];
                    newsp.Img = (string)reader["img"];
                    newsp.CreatedAt = (DateTime)reader["created_at"];
                    newsp.UpdatedAt = (DateTime)reader["updated_at"];
                    int adminId = (int)reader["ad_id"];

                    // Tạo đối tượng category và supplier chỉ với ID
                    newsp.AdminId = new admin { Id = adminId };

                    news.Add(newsp);
                }
            }
            return news;
        }
        public bool deleteNews(int newsId)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM NEWS WHERE ID = @newsId;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@newsId", newsId);
                int count = (int)command.ExecuteScalar();

                if (count == 0)
                {
                    connection.Close();
                    return false;
                }

                query = "DELETE FROM NEWS WHERE ID = @newsId;";
                command.CommandText = query;
                command.ExecuteNonQuery();
            }
            return true;
        }
        public news GetNewsById(int newsId)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT * FROM NEWS WHERE ID = @newsId;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@newsId", newsId);

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    var newsp = new news();
                    newsp.Id = (int)reader["id"];
                    newsp.Title = (string)reader["tittle"];
                    newsp.Content = (string)reader["content"];
                    newsp.Img = (string)reader["img"];
                    newsp.CreatedAt = (DateTime)reader["created_at"];
                    newsp.UpdatedAt = (DateTime)reader["updated_at"];
                    int adminId = (int)reader["ad_id"];

                    // Tạo đối tượng admin chỉ với ID
                    newsp.AdminId = new admin { Id = adminId };

                    return newsp;
                }
            }
            return null;
        }
        public int GetTotalNews()
        {
            int totalCount = 0;

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) AS TotalCount FROM NEWS;";
                command.CommandText = query;

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    totalCount = (int)reader["TotalCount"];
                }
            }

            return totalCount;
        }


    }
}