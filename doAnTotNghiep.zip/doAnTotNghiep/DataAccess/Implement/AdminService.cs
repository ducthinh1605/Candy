﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Newtonsoft.Json;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

namespace ECommerce.API.DataAccess
{
    public class AdminService : IAdmin
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public AdminService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }
        public bool InsertAdmin(admin ad)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM ADMINS WHERE id = @id;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@id", ad.Id);
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    connection.Close();
                    return false;
                }

                query = "INSERT INTO ADMINS (Name, Email, Account, Password, Phone, Address, Created_at, Updated_at) " +
                        "VALUES (@n, @em, @ac, @pwd,@pho,@add, @cre, @upd);";

                command.CommandText = query;
                command.Parameters.AddWithValue("@n", ad.Name);
                command.Parameters.AddWithValue("@em", ad.Email);
                command.Parameters.AddWithValue("@ac", ad.Account);
                command.Parameters.AddWithValue("@pwd", ad.Password); 
                command.Parameters.AddWithValue("@pho", ad.Phone);
                command.Parameters.AddWithValue("@add", ad.Address);
                command.Parameters.AddWithValue("@cre", DateTime.Now);
                command.Parameters.AddWithValue("@upd", DateTime.Now);
                command.ExecuteNonQuery();
            }
            return true;
        }
        public List<admin> GetAdmin()
        {
            var admins = new List<admin>();
            //ket noi database
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM admins";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var admin = new admin();
                    admin.Id = (int)reader["ID"];
                    admin.Name = (string)reader["Name"];
                    admin.Email = (string)reader["Email"];
                    admin.Account = (string)reader["Account"];
                    admin.Password = (string)reader["Password"];
                    admin.Phone = (int)reader["Phone"];
                    admin.Address= (string)reader["Address"];
                    admin.Created_at = (DateTime)reader["Created_at"];
                    admin.Updated_at = (DateTime)reader["Updated_at"];
                    admins.Add(admin);
                }
            }
            return admins;
        }
        public admin GetAdminById(int id)
        {
            admin Admin = null;

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM ADMINS WHERE id = @id";
                command.CommandText = query;
                command.Parameters.AddWithValue("id", id);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    Admin = new admin();
                    Admin.Id = (int)reader["id"];
                    Admin.Name = (string)reader["name"];
                    Admin.Email = (string)reader["email"];
                    Admin.Account = (string)reader["account"];
                    Admin.Password = (string)reader["password"];
                    Admin.Phone = (int)reader["phone"];
                    Admin.Address = (string)reader["address"];
                    Admin.Created_at = (DateTime)reader["Created_at"];
                    Admin.Updated_at = (DateTime)reader["Updated_at"];
                }
            }
            return Admin;
        }
        public bool GetAdminByAccAndPassword(admin ad)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                // Kiểm tra tồn tại người dùng
                string query = "SELECT COUNT(*) FROM ADMINS WHERE account=@acc AND password=@Password;";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@acc", ad.Account);
                    command.Parameters.AddWithValue("@Password", ad.Password);

                    int count = (int)command.ExecuteScalar();

                    // Trả về true nếu có người dùng tồn tại, ngược lại trả về false
                    return count > 0 ? true : false;
                }
            }
        }
        public bool Update(admin ad)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM ADMINS WHERE ID = @AdminId;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@AdminId", ad.Id);
                int count = (int)command.ExecuteScalar();

                if (count == 0)
                {
                    connection.Close();
                    return false;
                }

                query = "UPDATE ADMINS " +
                        "SET name = @n, email = @em, account = @acc, password = @pwd, phone = @ph,address=@add,created_at=@cre, updated_at = @upd " +
                        "WHERE ID = @AdminId;";

                command.CommandText = query;
                command.Parameters.AddWithValue("@n", ad.Name);
                command.Parameters.AddWithValue("@em", ad.Email);
                command.Parameters.AddWithValue("@acc", ad.Account);
                command.Parameters.AddWithValue("@pwd", ad.Password);
                command.Parameters.AddWithValue("@ph", ad.Phone);
                command.Parameters.AddWithValue("@add", ad.Address);
                command.Parameters.AddWithValue("@cre", DateTime.Now);
                command.Parameters.AddWithValue("@upd", DateTime.Now);

                command.ExecuteNonQuery();
            }
            return true;
        }
        public bool Delete(int id)
        {
            using (SqlConnection connection = new(dbconnection)) // ket noi database
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };
                connection.Open();
                string query = "SELECT COUNT(*) FROM ADMINS WHERE ID ='" + id + "' ;";
                command.CommandText = query;
                int count = (int)command.ExecuteScalar();
                if (count == 0)
                {
                    connection.Close();
                    return false;
                }

                query = "DELETE FROM ADMINS WHERE ID='" + id + "';";
                command.CommandText = query;

                command.ExecuteNonQuery();
            }
            return true;
        }
        public int GetAdminId(string account, string password)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                string query = "SELECT ID FROM ADMINS WHERE account=@acc AND password=@Password;";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@acc", account);
                    command.Parameters.AddWithValue("@Password", password);

                    object result = command.ExecuteScalar();

                    // If the result is not null, return the admin ID; otherwise, return -1 or any other suitable indicator
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
        }



    }
}