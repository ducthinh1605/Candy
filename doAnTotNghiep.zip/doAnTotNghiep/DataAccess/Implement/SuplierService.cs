﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;
using System.Data;

namespace ECommerce.API.DataAccess
{
    public class SuplierService : Isuplier
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public SuplierService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }

        public bool insertSup(suplier sup)
        {
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM SUPPLIER WHERE id='" + sup.id + "';";
                command.CommandText = query;
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    connection.Close();
                    return false;
                }

                query = "INSERT INTO SUPPLIER ( name, img,website,  description,created_at,updated_at) VALUES( @n, @img,@web, @des,@cre,@up); ";

                command.CommandText = query;
                command.Parameters.Add("@n", System.Data.SqlDbType.NVarChar).Value = sup.name;
                command.Parameters.Add("@img", System.Data.SqlDbType.NVarChar).Value = sup.img;
                command.Parameters.Add("@web", System.Data.SqlDbType.NVarChar).Value = sup.website;
                command.Parameters.Add("@des", System.Data.SqlDbType.NVarChar).Value = sup.description;
                command.Parameters.AddWithValue("@cre", DateTime.Now);
                command.Parameters.AddWithValue("@up", DateTime.Now);
                command.ExecuteNonQuery();
            }
            return true;

        }
        public List<suplier> GetSup()
        {
            var suppliers = new List<suplier>();
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM SUPPLIER";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var sup = new suplier();
                    sup.id = (int)reader["id"];
                    sup.name = (string)reader["name"];
                    sup.img = (string)reader["img"];
                    sup.website = (string)reader["website"];
                    sup.description = (string)reader["description"];
                    sup.Created_at = (DateTime)reader["created_at"];
                    sup.Updated_at = (DateTime)reader["updated_at"];

                    suppliers.Add(sup);
                }
            }
            return suppliers;
        }

        public suplier GetSupById(int id)
        {
            var sup = new suplier();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = connection;

                string query = "SELECT * FROM SUPPLIER WHERE ID=" + id + ";";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    sup.id = (int)reader["id"];
                    sup.name = (string)reader["name"];
                    sup.img = (string)reader["img"];
                    sup.website = (string)reader["website"];
                    sup.description = (string)reader["description"];
                    sup.Created_at = (DateTime)reader["created_at"];
                    sup.Updated_at = (DateTime)reader["updated_at"];
                }

                connection.Close();
            }

            return sup;
        }

        public bool UpdateSup(suplier sup)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT COUNT(*) FROM SUPPLIER WHERE id=@id;";
                command.CommandText = query;
                command.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = sup.id;

                connection.Open();
                int count = (int)command.ExecuteScalar();
                if (count == 0)
                {
                    connection.Close();
                    return false; // Không tìm thấy nhà cung cấp để cập nhật
                }

                query = "UPDATE SUPPLIER SET name=@name, img=@img, website=@website, description=@description, " +
                        "created_at=@created_at, updated_at=@updated_at WHERE id=@id;";

                command.CommandText = query;
                command.Parameters.Add("@name", SqlDbType.NVarChar).Value = sup.name;
                command.Parameters.Add("@img", SqlDbType.NVarChar).Value = sup.img;
                command.Parameters.Add("@website", SqlDbType.NVarChar).Value = sup.website;
                command.Parameters.Add("@description", SqlDbType.NVarChar).Value = sup.description;
                command.Parameters.AddWithValue("@created_at", DateTime.Now);
                command.Parameters.AddWithValue("@updated_at", DateTime.Now);

                command.ExecuteNonQuery();
                connection.Close();
            }

            return true; // Cập nhật thành công
        }

        public bool DeleteSup(int id)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT COUNT(*) FROM SUPPLIER WHERE id=@id;";
                command.CommandText = query;
                command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                connection.Open();
                int count = (int)command.ExecuteScalar();
                if (count == 0)
                {
                    connection.Close();
                    return false; // Không tìm thấy nhà cung cấp để xóa
                }

                query = "DELETE FROM SUPPLIER WHERE id=@id;";
                command.CommandText = query;

                command.ExecuteNonQuery();
                connection.Close();
            }

            return true; // Xóa thành công
        }
        public int GetTotalOfSup()
        {
            var totalSup = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open(); // Mở kết nối tại đây để đảm bảo kết nối được đóng sau khi hoàn tất công việc

                    SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Supplier", connection);
                    totalSup = (int)command.ExecuteScalar();
                }
            }
            catch (SqlException ex)
            {
                // Xử lý lỗi kết nối
                Console.WriteLine("Error connecting to the database: " + ex.Message);
                // Có thể thêm các xử lý khác tùy vào yêu cầu
            }

            return totalSup;
        }
    }
}
