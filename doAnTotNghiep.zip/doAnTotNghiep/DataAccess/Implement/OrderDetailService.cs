﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Newtonsoft.Json;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;
using System.Net.Mail;

namespace ECommerce.API.DataAccess
{
    public class OrderDetailService : IOrderDetail
    {
        private readonly IConfiguration configuration;
        private readonly IProduct productService;
        private readonly IOrder orderService;
        private readonly IUserService userService;
        private readonly string dbconnection;

        public OrderDetailService(IConfiguration configuration, IProduct productService, IOrder orderService, IUserService userService)
        {
            this.configuration = configuration;
            this.productService = productService;
            this.orderService = orderService;
            this.userService = userService;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }

     
        public List<orderDetails> GetOrderDetails(int orderId)
        {
            var orderDetailsList = new List<orderDetails>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    string query = " SELECT * " +
                                    " FROM ORDER_DETAILS od " +
                                    " INNER JOIN PRODUCT p ON od.pro_id = p.id " +
                                    " INNER JOIN ORDERS o ON od.order_id = o.id " +
                                    " WHERE od.order_id = @OrderId ";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@OrderId", orderId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var orderDetails = new orderDetails()
                                {
                                    pro_id = new product()
                                    {
                                        id = (int)reader["id"],
                                        name = (string)reader["name"],
                                        price = (int)reader["price"],
                                        img = (string)reader["img"]
                                        
                                    },
                                    order_id = new orders()
                                    {
                                        Id = (int)reader["id"],
                                        OrderName = (string)reader["order_name"],
                                        OrderPhone = (int)reader["order_phone"],
                                        OrderCity = (string)reader["order_city"],
                                        OrderDistrict = (string)reader["order_district"],
                                        OrderWard = (string)reader["order_ward"],
                                        OrderStreet = (string)reader["order_street"],
                                        Note = (string)reader["note"],
                                        status = (int)reader["status"],
                                        total = (int)reader["total"],

                                        
                                    },
                                    qty = (int)reader["qty"],
                                    discount_price = (int)reader["discount_price"],
                                    total_price = (int)reader["total_price"],
                                    CreatedAt = (DateTime)reader["created_at"],
                                    UpdatedAt = (DateTime)reader["updated_at"],
                                };

                                orderDetailsList.Add(orderDetails);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            return orderDetailsList;
        }
        public List<orderDetails> GetORDByUserID(int userId)
        {
            var orderDetailsList = new List<orderDetails>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    string query = " SELECT * " +
                                    " FROM ORDER_DETAILS od " +
                                    " INNER JOIN PRODUCT p ON od.pro_id = p.id " +
                                    " INNER JOIN ORDERS o ON od.order_id = o.id " +
                                    " INNER JOIN USERS u ON o.users_id = u.id " +
                                    " WHERE u.id = @UserId ";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserId", userId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var orderDetails = new orderDetails()
                                {
                                    pro_id = new product()
                                    {
                                        id = (int)reader["id"],
                                        name = (string)reader["name"],
                                        price = (int)reader["price"],
                                        img = (string)reader["img"]

                                    },
                                    order_id = new orders()
                                    {
                                        Id = (int)reader["id"],
                                        OrderName = (string)reader["order_name"],
                                        OrderPhone = (int)reader["order_phone"],
                                        OrderCity = (string)reader["order_city"],
                                        OrderDistrict = (string)reader["order_district"],
                                        OrderWard = (string)reader["order_ward"],
                                        OrderStreet = (string)reader["order_street"],
                                        Note = (string)reader["note"],
                                        status = (int)reader["status"],
                                        total = (int)reader["total"],

                                    },
                                    qty = (int)reader["qty"],
                                    discount_price = (int)reader["discount_price"],
                                    total_price = (int)reader["total_price"],
                                    CreatedAt = (DateTime)reader["created_at"],
                                    UpdatedAt = (DateTime)reader["updated_at"],
                                };

                                orderDetailsList.Add(orderDetails);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            return orderDetailsList;
        }
        public bool InsertOrder(orderReq order)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    // Kiểm tra xem người dùng có tồn tại không trước khi thêm đơn hàng
                    User existingUser = userService.GetUser(order.UsersId);
                    if (existingUser == null)
                    {
                        return false; // Trả về false nếu người dùng không tồn tại
                    }

                    // Thực hiện INSERT đơn hàng vào cơ sở dữ liệu
                    string insertQuery = "INSERT INTO ORDERS (order_name, order_phone, order_city, order_district, order_ward, " +
                                          "order_street, note, status, total, created_at, updated_at, users_id, admin_id, pm_id) " +
                                          "VALUES (@orderName, @orderPhone, @orderCity, @orderDistrict, @orderWard, " +
                                          "@orderStreet, @note, @status, @total, @createdAt, @updatedAt, @usersId, @adminId, @pmId)" +
                                          "SELECT SCOPE_IDENTITY();";
                    int orderId; //lấy ID của đơn hàng vừa chèn
                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@orderName", order.OrderName);
                        insertCommand.Parameters.AddWithValue("@orderPhone", order.OrderPhone);
                        insertCommand.Parameters.AddWithValue("@orderCity", order.OrderCity);
                        insertCommand.Parameters.AddWithValue("@orderDistrict", order.OrderDistrict);
                        insertCommand.Parameters.AddWithValue("@orderWard", order.OrderWard);
                        insertCommand.Parameters.AddWithValue("@orderStreet", order.OrderStreet);
                        insertCommand.Parameters.AddWithValue("@note", order.Note);
                        insertCommand.Parameters.AddWithValue("@status", 0); // Thiết lập trạng thái mặc định
                        insertCommand.Parameters.AddWithValue("@total", CalculateTotalFromCart(order.UsersId, connection)); // Lấy giá trị total từ cart
                        insertCommand.Parameters.AddWithValue("@createdAt", DateTime.Now);
                        insertCommand.Parameters.AddWithValue("@updatedAt", DateTime.Now);
                        insertCommand.Parameters.AddWithValue("@usersId", order.UsersId);
                        insertCommand.Parameters.AddWithValue("@adminId", 1); // ID của admin 
                        insertCommand.Parameters.AddWithValue("@pmId", order.PmId);

                        //int affectedRows = insertCommand.ExecuteNonQuery();

                        orderId = Convert.ToInt32(insertCommand.ExecuteScalar());
                    }
                    if (orderId > 0)
                    {
                        // Nếu có ID của đơn hàng, chèn dữ liệu vào bảng ORDER_DETAILS
                        string insertOrderDetailsQuery = @"
                            INSERT INTO ORDER_DETAILS (pro_id, order_id, qty, discount_price, total_price, created_at, updated_at)
                            SELECT C.pro_id, O.id, C.qty, 0, C.total_price, GETDATE(), GETDATE()
                            FROM ORDERS O
                            JOIN CART C ON O.users_id = C.users_id
                            WHERE O.id = @OrderId";

                        using (SqlCommand insertOrderDetailsCommand = new SqlCommand(insertOrderDetailsQuery, connection))
                        {
                            // Thiết lập tham số cho việc chèn ORDER_DETAILS
                            insertOrderDetailsCommand.Parameters.AddWithValue("@OrderId", orderId);
                            int affectedRows = insertOrderDetailsCommand.ExecuteNonQuery();
                            if (affectedRows > 0)
                            {
                                // Nếu chèn dữ liệu thành công vào ORDER_DETAILS, tiến hành xóa số lượng sản phẩm từ PRODUCT
                                SendEmailToUser(order.UsersId);
                                string updateProductQtyQuery = @"
                                    UPDATE PRODUCT
                                    SET qty = p.qty - OD.qty
                                    FROM PRODUCT P
                                    INNER JOIN ORDER_DETAILS OD ON P.id = OD.pro_id
                                    WHERE OD.order_id = @OrderId";

                                using (SqlCommand updateProductQtyCommand = new SqlCommand(updateProductQtyQuery, connection))
                                {
                                    updateProductQtyCommand.Parameters.AddWithValue("@OrderId", orderId);
                                    int updatedRows = updateProductQtyCommand.ExecuteNonQuery();

                                    if (updatedRows > 0)
                                    {
                                        // Nếu xóa số lượng sản phẩm thành công từ PRODUCT, tiến hành xóa dữ liệu từ CART
                                        string deleteCartQuery = "DELETE FROM CART WHERE users_id = @UsersId";

                                        using (SqlCommand deleteCartCommand = new SqlCommand(deleteCartQuery, connection))
                                        {
                                            deleteCartCommand.Parameters.AddWithValue("@UsersId", order.UsersId);
                                            int deletedRows = deleteCartCommand.ExecuteNonQuery();

                                            return deletedRows > 0;
                   
                                        }
                                    }
                                }
                            }
                        }
                    }

                    return false; // Trả về false nếu không có ID đơn hàng hoặc có lỗi xảy ra
                }
            }
            catch (Exception ex)
            {
                // Xử lý nếu có lỗi xảy ra trong quá trình thực hiện
                return false;
            }
        }


        private decimal CalculateTotalFromCart(int userId, SqlConnection connection)
        {
            decimal total = 0;
            try
            {
                string cartTotalQuery = "SELECT SUM(total_price) FROM CART WHERE users_id = @userId";
                using (SqlCommand cartTotalCommand = new SqlCommand(cartTotalQuery, connection))
                {
                    cartTotalCommand.Parameters.AddWithValue("@userId", userId);
                    object result = cartTotalCommand.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        total = Convert.ToDecimal(result);

                        // Thêm phí ship nếu tổng giá trị đơn hàng bé hơn 150,000
                        if (total < 150000)
                        {
                            total += 30000;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý nếu có lỗi xảy ra trong quá trình tính toán
            }

            return total;
        }


        public string CreateEmailContentForCart(int orderId)
        {
            List<orderDetails> userOrder = GetORDByUserID(orderId);
            StringBuilder emailContent = new StringBuilder();

            emailContent.AppendLine("Chào bạn,");
            emailContent.AppendLine("Dưới đây là thông tin chi tiết về giỏ hàng của bạn:");

            foreach (var item in userOrder)
            {
                emailContent.AppendLine($"Tên người đặt: {item.order_id.OrderName} - Số Điện Thoại: {item.order_id.OrderPhone} - Địa chỉ: {item.order_id.OrderStreet}" +
                                        $" {item.order_id.OrderWard} {item.order_id.OrderDistrict} {item.order_id.OrderCity}");
                emailContent.AppendLine($"Sản phẩm: {item.pro_id.name} - Số lượng: {item.qty} - Giá: {item.pro_id.price} - Tổng: {item.total_price}");
            }

            // Thêm thông tin tổng giá trị đơn hàng
            int totalPrice = userOrder.Sum(item => item.total_price);
            emailContent.AppendLine($"Tổng giá trị đơn hàng: {totalPrice}");

            // Thêm lời chào kết thúc
            emailContent.AppendLine("Chúc bạn có một ngày tốt lành!");
            emailContent.AppendLine("Thân mến,");
            emailContent.AppendLine("Đội ngũ cửa hàng");

            return emailContent.ToString();
        }
        private static readonly string _from = "CandyTT12@outlook.com"; // Email của Sender (của bạn)
        private static readonly string _pass = "Thinhbo123"; // Mật khẩu Email của Sender (của bạn)   
        public bool SendEmailToUser(int userId)
        {
            // Lấy địa chỉ email của người dùng
            string userEmail = GetUserEmailById(userId);
            // Tạo một email và gửi
            string emailContent = CreateEmailContentForCart(userId);
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.office365.com");

                mail.From = new MailAddress(_from);
                mail.To.Add(userEmail);
                mail.Subject = "Thông Tin Giỏ Hàng Của Bạn";
                mail.Body = emailContent;
                mail.Priority = MailPriority.High;

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential(_from, _pass);
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                Console.WriteLine("Email đã được gửi thành công.");
                return true; // Trả về true khi email được gửi thành công
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi gửi email: {ex.Message}");
                return false; // Trả về false khi có lỗi
            }
        }

        public string GetUserEmailById(int userId)
        {
            string userEmail = string.Empty;
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                string query = "SELECT email FROM USERS WHERE id = @userId ";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userId", userId);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userEmail = (string)reader["email"];
                        }
                    }
                }
            }
                
            return userEmail;
        }


    }
}
