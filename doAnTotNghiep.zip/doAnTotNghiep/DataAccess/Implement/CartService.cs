﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Newtonsoft.Json;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;
using System.Net.Mail;

namespace ECommerce.API.DataAccess
{
    public class CartService : Icart
    {
        private readonly IConfiguration configuration;
        private readonly IProduct productService;
        private readonly IUserService userService;
        private readonly string dbconnection;

        public CartService(IConfiguration configuration, IProduct productService, IUserService userService)
        {
            this.configuration = configuration;
            this.productService = productService;
            this.userService = userService;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }

        public bool InsertCart(int userId, int productId, int qty)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();
                    string checkAvailabilityQuery = "SELECT qty FROM PRODUCT WHERE id = @productId";
                    using (SqlCommand checkAvailabilityCommand = new SqlCommand(checkAvailabilityQuery, connection))
                    {
                        checkAvailabilityCommand.Parameters.AddWithValue("@productId", productId);

                        int availableQty = (int)checkAvailabilityCommand.ExecuteScalar();

                        if (availableQty < qty)
                        {
                            // Số lượng yêu cầu vượt quá số lượng có sẵn, không thể thêm vào giỏ hàng
                            return false;
                        }

                        // Kiểm tra sự tồn tại của sản phẩm trong giỏ hàng
                        string checkExistQuery = "SELECT COUNT(*) FROM CART WHERE users_id = @userId AND pro_id = @productId";
                        using (SqlCommand checkExistCommand = new SqlCommand(checkExistQuery, connection))
                        {
                            checkExistCommand.Parameters.AddWithValue("@userId", userId);
                            checkExistCommand.Parameters.AddWithValue("@productId", productId);

                            int recordCount = (int)checkExistCommand.ExecuteScalar();

                            if (recordCount < 0)
                            {
                                // Lỗi khi truy xuất cơ sở dữ liệu
                                return false;
                            }

                            if (recordCount == 0)
                            {
                                // Lấy thông tin sản phẩm từ bảng PRODUCT
                                string getProductInfoQuery = "SELECT price FROM PRODUCT WHERE id = @productId";
                                using (SqlCommand getProductInfoCommand = new SqlCommand(getProductInfoQuery, connection))
                                {
                                    getProductInfoCommand.Parameters.AddWithValue("@productId", productId);

                                    // ExecuteScalar để lấy giá sản phẩm
                                    int price = Convert.ToInt32(getProductInfoCommand.ExecuteScalar());

                                    // Tính toán total_price
                                    int total_price = price * qty;

                                    // Sản phẩm chưa tồn tại trong giỏ hàng, thêm mới
                                    string insertQuery = "INSERT INTO CART (pro_id, users_id, qty, total_price, created_at, updated_at)  " +
                                                         "VALUES (@productId, @userId, @qty, @total, @createdTime, @updatedTime)";
                                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                                    {
                                        insertCommand.Parameters.AddWithValue("@productId", productId);
                                        insertCommand.Parameters.AddWithValue("@userId", userId);
                                        insertCommand.Parameters.AddWithValue("@total", total_price);
                                        insertCommand.Parameters.AddWithValue("@qty", qty);
                                        insertCommand.Parameters.AddWithValue("@createdTime", DateTime.Now);
                                        insertCommand.Parameters.AddWithValue("@updatedTime", DateTime.Now);

                                        int affectedRows = insertCommand.ExecuteNonQuery();
                                        return affectedRows > 0;
                                    }
                                }
                            }
                            else
                            {
                                // Sản phẩm đã tồn tại trong giỏ hàng, cập nhật số lượng
                                string updateQuery = "UPDATE CART SET qty = qty + @qty, updated_at = @updatedTime, total_price = @total " +
                                                     "WHERE pro_id = @productId AND users_id = @userId";
                                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                                {
                                    updateCommand.Parameters.AddWithValue("@qty", qty);
                                    updateCommand.Parameters.AddWithValue("@productId", productId);
                                    updateCommand.Parameters.AddWithValue("@userId", userId);
                                    updateCommand.Parameters.AddWithValue("@updatedTime", DateTime.Now);

                                    // ExecuteScalar để lấy giá sản phẩm
                                    string getPriceQuery = "SELECT price FROM PRODUCT WHERE id = @productId";
                                    using (SqlCommand getPriceCommand = new SqlCommand(getPriceQuery, connection))
                                    {
                                        getPriceCommand.Parameters.AddWithValue("@productId", productId);

                                        // ExecuteScalar để lấy giá sản phẩm
                                        int price = Convert.ToInt32(getPriceCommand.ExecuteScalar());

                                        // Tính toán và đặt giá trị mới cho cột total
                                        int total = price * qty;
                                        updateCommand.Parameters.AddWithValue("@total", total);
                                    }

                                    int affectedRows = updateCommand.ExecuteNonQuery();
                                    return affectedRows > 0;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý exception nếu có lỗi xảy ra trong quá trình thực hiện
                Console.WriteLine($"Lỗi khi thực hiện InsertCart: {ex.Message}");
                return false;
            }
        }

        public List<cart> GetCart(int userId)
        {
            List<cart> userCart = new List<cart>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    // Truy vấn để lấy thông tin giỏ hàng của người dùng
                    string getCartQuery = "SELECT * FROM CART WHERE users_id = @userId";
                    using (SqlCommand getCartCommand = new SqlCommand(getCartQuery, connection))
                    {
                        getCartCommand.Parameters.AddWithValue("@userId", userId);

                        using (SqlDataReader reader = getCartCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cart cartItem = new cart
                                {
                                    // Lấy thông tin từ cơ sở dữ liệu và thêm vào đối tượng Cart
                                    Id = Convert.ToInt32(reader["id"]),
                                    users_id = userService.GetUser((int)reader["users_id"]),
                                    pro_id = productService.GetProductById((int)reader["pro_id"]),
                                    qty = Convert.ToInt32(reader["qty"]),
                                    total_price = Convert.ToInt32(reader["total_price"]),
                                    CreatedAt = Convert.ToDateTime(reader["created_at"]),
                                    UpdatedAt = Convert.ToDateTime(reader["updated_at"])
                                    // Thêm các trường thông tin khác từ bảng CART
                                };

                                userCart.Add(cartItem);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi lấy thông tin giỏ hàng: {ex.Message}");
            }

            return userCart;
        }
        public bool DeleteCartItem(int userId, int productId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    // Xóa mục giỏ hàng cụ thể dựa trên userId và productId
                    string deleteCartQuery = "DELETE FROM CART WHERE users_id = @userId AND pro_id = @productId";
                    using (SqlCommand deleteCartCommand = new SqlCommand(deleteCartQuery, connection))
                    {
                        deleteCartCommand.Parameters.AddWithValue("@userId", userId);
                        deleteCartCommand.Parameters.AddWithValue("@productId", productId);

                        int rowsAffected = deleteCartCommand.ExecuteNonQuery();
                        return rowsAffected > 0; // Trả về true nếu xóa thành công
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý exception nếu có lỗi xảy ra
                Console.WriteLine($"Lỗi khi thực hiện DeleteCartItem: {ex.Message}");
                return false;
            }
        }

        public bool UpdateCart(int userId, int productId, int newQty)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    // Kiểm tra số lượng sản phẩm có đủ để cập nhật không
                    string checkAvailabilityQuery = "SELECT qty FROM PRODUCT WHERE id = @productId";
                    using (SqlCommand checkAvailabilityCommand = new SqlCommand(checkAvailabilityQuery, connection))
                    {
                        checkAvailabilityCommand.Parameters.AddWithValue("@productId", productId);

                        int availableQty = (int)checkAvailabilityCommand.ExecuteScalar();

                        if (availableQty < newQty)
                        {
                            // Số lượng yêu cầu vượt quá số lượng có sẵn, không thể cập nhật giỏ hàng
                            return false;
                        }

                        // Lấy giá sản phẩm từ bảng PRODUCT
                        string getPriceQuery = "SELECT price FROM PRODUCT WHERE id = @productId";
                        using (SqlCommand getPriceCommand = new SqlCommand(getPriceQuery, connection))
                        {
                            getPriceCommand.Parameters.AddWithValue("@productId", productId);

                            // ExecuteScalar để lấy giá sản phẩm
                            object priceResult = getPriceCommand.ExecuteScalar();
                            if (priceResult != null && int.TryParse(priceResult.ToString(), out int price))
                            {
                                // Nếu lấy được giá sản phẩm, thực hiện việc cập nhật giỏ hàng
                                string updateCartQuery = "UPDATE CART SET qty = @newQty, total_price = @totalPrice, updated_at = GETDATE() WHERE users_id = @userId AND pro_id = @productId";
                                using (SqlCommand updateCartCommand = new SqlCommand(updateCartQuery, connection))
                                {
                                    updateCartCommand.Parameters.AddWithValue("@newQty", newQty);
                                    updateCartCommand.Parameters.AddWithValue("@totalPrice", price * newQty);
                                    updateCartCommand.Parameters.AddWithValue("@userId", userId);
                                    updateCartCommand.Parameters.AddWithValue("@productId", productId);

                                    int rowsAffected = updateCartCommand.ExecuteNonQuery();
                                    if (rowsAffected > 0)
                                    {
                                        return true; // Trả về true nếu cập nhật thành công
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý exception nếu có lỗi xảy ra trong quá trình thực hiện
                Console.WriteLine($"Lỗi khi thực hiện UpdateCart: {ex.Message}");
                return false;
            }

            return false; // Trả về false nếu có lỗi xảy ra hoặc không cập nhật được
        }




    }
}