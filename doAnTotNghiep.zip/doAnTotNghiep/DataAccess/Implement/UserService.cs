﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Newtonsoft.Json;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Mail;

namespace ECommerce.API.DataAccess
{
    public class UserService : IUserService
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public UserService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }
        public User GetUser(int id)
        {
            var user = new User();
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM Users WHERE ID=" + id + ";";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    user.Id = (int)reader["ID"];
                    user.Name = (string)reader["Name"];
                    user.Email = (string)reader["Email"];
                    user.Account = (string)reader["Account"];
                    user.Password = (string)reader["Password"];
                    user.Phone = (int)reader["Phone"];
                    user.Created_at = (DateTime)reader["Created_at"];
                    user.Updated_at = (DateTime)reader["Updated_at"];
                }
            }
            return user;
        }

        public bool InsertUser(User user)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                try
                {
                    string query = "SELECT COUNT(*) FROM Users WHERE id = @id;";
                    command.CommandText = query;
                    command.Parameters.AddWithValue("@id", user.Id);
                    int count = (int)command.ExecuteScalar();
                    if (count > 0)
                    {
                        return false; // Người dùng đã tồn tại, không thể thêm
                    }

                    string hashedPassword = HashPassword(user.Password);
                    query = "INSERT INTO Users (Name, Email, Account, Password, Phone, Created_at, Updated_at) " +
                            "VALUES (@n, @em, @ac, @pwd, @pho, @cre, @upd);";

                    command.CommandText = query;
                    command.Parameters.AddWithValue("@n", user.Name);
                    command.Parameters.AddWithValue("@em", user.Email);
                    command.Parameters.AddWithValue("@ac", user.Account);
                    command.Parameters.AddWithValue("@pwd", hashedPassword);
                    command.Parameters.AddWithValue("@pho", user.Phone);
                    command.Parameters.AddWithValue("@cre", DateTime.Now);
                    command.Parameters.AddWithValue("@upd", DateTime.Now);
                    command.ExecuteNonQuery();

                    return true; // Thêm người dùng thành công
                }
                catch (Exception ex)
                {
                    // Log the exception or handle it as needed
                    // Returning false to indicate insertion failure
                    return false;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        public string HashPassword(string password)
        {
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                // Mã hóa mật khẩu thành một chuỗi byte
                byte[] hashedBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(password));

                // Chuyển đổi chuỗi byte thành chuỗi hex để lưu trữ
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashedBytes.Length; i++)
                {
                    builder.Append(hashedBytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        public bool GetUserByAccAndPassword(User user)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                connection.Open();

                // Lấy mật khẩu đã mã hóa từ cơ sở dữ liệu
                string query = "SELECT password FROM USERS WHERE account=@acc;";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@acc", user.Account);
                    string storedPassword = (string)command.ExecuteScalar();

                    if (storedPassword != null)
                    {
                        // Mã hóa mật khẩu nhập vào để so sánh với mật khẩu đã mã hóa trong DB
                        string hashedPassword = HashPassword(user.Password);

                        // So sánh mật khẩu đã mã hóa từ DB với mật khẩu đã mã hóa từ đầu vào
                        return hashedPassword.Equals(storedPassword, StringComparison.OrdinalIgnoreCase);
                    }
                }
            }

            return false;
        }
        public List<User> GetAllUser()
        {
            var users = new List<User>();
            //ket noi database
            using (SqlConnection connection = new(dbconnection))
            {
                SqlCommand command = new()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM Users";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var user = new User();
                    user.Id = (int)reader["ID"];
                    user.Name = (string)reader["Name"];
                    user.Email = (string)reader["Email"];
                    user.Account = (string)reader["Account"];
                    user.Password = (string)reader["Password"];
                    user.Phone = (int)reader["Phone"];
                    user.Created_at = (DateTime)reader["Created_at"];
                    user.Updated_at = (DateTime)reader["Updated_at"];
                    users.Add(user);
                }
            }
            return users;
        }
        public bool Delete(int id)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();

                    // Kiểm tra xem người dùng có tồn tại không
                    command.CommandText = "SELECT COUNT(*) FROM USERS WHERE id = @UserID";
                    command.Parameters.AddWithValue("@UserID", id);
                    int count = (int)command.ExecuteScalar();

                    if (count == 0)
                    {
                        return false; // Không tìm thấy người dùng, không thực hiện xóa
                    }

                    // Xóa dữ liệu từ bảng ORDER_DETAILS có liên kết với người dùng
                    command.Parameters.Clear(); // Xóa các tham số cũ
                    command.CommandText = "DELETE FROM ORDER_DETAILS WHERE order_id IN (SELECT id FROM ORDERS WHERE id = @UserID)";
                    command.Parameters.AddWithValue("@UserID", id);
                    command.ExecuteNonQuery();

                    command.Parameters.Clear(); // Xóa các tham số cũ
                    command.CommandText = "DELETE FROM ORDERS WHERE users_id =@UserID";
                    command.Parameters.AddWithValue("@UserID", id);
                    command.ExecuteNonQuery();

                    // Cuối cùng, xóa người dùng từ bảng USERS
                    command.Parameters.Clear(); // Xóa các tham số cũ
                    command.CommandText = "DELETE FROM USERS WHERE id = @UserID";
                    command.Parameters.AddWithValue("@UserID", id);
                    command.ExecuteNonQuery();
                }
            }
            return true; // Xóa thành công
        }


        public bool Update(User user)
        {
            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };
                connection.Open();

                string query = "SELECT COUNT(*) FROM Users WHERE ID = @userId;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@userId", user.Id);
                int count = (int)command.ExecuteScalar();

                if (count == 0)
                {
                    connection.Close();
                    return false;
                }

                // Mã hóa mật khẩu trước khi cập nhật
                string hashedPassword = HashPassword(user.Password);

                query = "UPDATE Users " +
                        "SET Name = @n, Email = @em, Account = @acc, Phone = @ph, updated_at = @upd " +
                        "WHERE ID = @userId;";

                command.CommandText = query;
                command.Parameters.AddWithValue("@n", user.Name);
                command.Parameters.AddWithValue("@em", user.Email);
                command.Parameters.AddWithValue("@acc", user.Account);
                command.Parameters.AddWithValue("@ph", user.Phone);
                command.Parameters.AddWithValue("@upd", DateTime.Now);

                command.ExecuteNonQuery();
            }
            return true;
        }

        public int GetTotalOfUser()
        {
            var totalUsers = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open(); // Mở kết nối tại đây để đảm bảo kết nối được đóng sau khi hoàn tất công việc

                    SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM USERS", connection);
                    totalUsers = (int)command.ExecuteScalar();
                }
            }
            catch (SqlException ex)
            {
                // Xử lý lỗi kết nối
                Console.WriteLine("Error connecting to the database: " + ex.Message);
                // Có thể thêm các xử lý khác tùy vào yêu cầu
            }

            return totalUsers;
        }
        public User GetUserInfo(string account, string password)
        {
            var user = new User();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                string query = "SELECT * FROM Users WHERE Account = @username;";
                command.CommandText = query;
                command.Parameters.AddWithValue("@username", account);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    user.Id = (int)reader["ID"];
                    user.Name = (string)reader["Name"];
                    user.Email = (string)reader["Email"];
                    user.Account = (string)reader["Account"];
                    user.Password = (string)reader["Password"];
                    user.Phone = (int)reader["Phone"];
                    user.Created_at = (DateTime)reader["Created_at"];
                    user.Updated_at = (DateTime)reader["Updated_at"];
                }
            }

            if (user.Password != null)
            {
                string hashedPassword = HashPassword(password);
                if (!hashedPassword.Equals(user.Password, StringComparison.OrdinalIgnoreCase))
                {
                    user = null;
                }
            }
            else
            {
            
                user = null;
            }

            return user;
        }


        public void GenerateVerificationCode()
        {
            Random random = new Random();
            verificationKey = random.Next(100000, 999999); // Sinh số nguyên ngẫu nhiên từ 100000 đến 999999
        }
        public static int verificationKey;
        private static readonly string _from = "CandyTT12@outlook.com"; // Email của Sender (của bạn)
        private static readonly string _pass = "Thinhbo123"; // Mật khẩu Email của Sender (của bạn)   

        public bool SendVerificationCodeEmail(string email)
        {
            GenerateVerificationCode();
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.office365.com");

                mail.From = new MailAddress(_from);
                mail.To.Add(email);
                mail.Subject = "Verification Code";
                mail.Body = "Your verification code is: " + verificationKey;
                Console.WriteLine(verificationKey);

                mail.Priority = MailPriority.High;

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential(_from, _pass);
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error sending email: " + ex.Message);
                return false;
            }
        }
        public int newVariable = verificationKey;
        public bool CompareVerificationCode(int userInput)
        {
            if (userInput == newVariable)
            {
                Console.WriteLine("Verification Successful!");
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<User> GetAllUserOrderByLatest()
        {
            var users = new List<User>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                // Modify the query to include an ORDER BY clause to retrieve users by the latest first
                string query = "SELECT * FROM Users ORDER BY Created_at DESC";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var user = new User();
                    user.Id = (int)reader["ID"];
                    user.Name = (string)reader["Name"];
                    user.Email = (string)reader["Email"];
                    user.Account = (string)reader["Account"];
                    user.Password = (string)reader["Password"];
                    user.Phone = (int)reader["Phone"];
                    user.Created_at = (DateTime)reader["Created_at"];
                    user.Updated_at = (DateTime)reader["Updated_at"];
                    users.Add(user);
                }
            }

            return users;
        }
        public List<User> GetAllUserOrderByName()
        {
            var users = new List<User>();

            using (SqlConnection connection = new SqlConnection(dbconnection))
            {
                SqlCommand command = new SqlCommand()
                {
                    Connection = connection
                };

                // Modify the query to include an ORDER BY clause to retrieve users by name A-Z
                string query = "SELECT * FROM Users ORDER BY Name";
                command.CommandText = query;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var user = new User();
                    user.Id = (int)reader["ID"];
                    user.Name = (string)reader["Name"];
                    user.Email = (string)reader["Email"];
                    user.Account = (string)reader["Account"];
                    user.Password = (string)reader["Password"];
                    user.Phone = (int)reader["Phone"];
                    user.Created_at = (DateTime)reader["Created_at"];
                    user.Updated_at = (DateTime)reader["Updated_at"];
                    users.Add(user);
                }
            }

            return users;
        }





    }
}


