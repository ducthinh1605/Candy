﻿using System;
using ECommerce.API.DataAccess;
using ECommerce.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Cors;
using System.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using ECommerce.API.Models.Request;
using System.Data;
using System.Text.RegularExpressions;

namespace ECommerce.API.DataAccess
{
    public class ContactService : IContact
    {
        private readonly IConfiguration configuration;
        private readonly string dbconnection;

        public ContactService(IConfiguration configuration)
        {
            this.configuration = configuration;
            dbconnection = this.configuration["ConnectionStrings:DB"];
        }
        public bool insertContact(contactReq contact)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    string query = @"INSERT INTO Contact (status, content, created_at, updated_at, users_id) 
                             VALUES (@Status, @Content, @CreatedAt, @UpdatedAt, @UserId);";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Status",0);
                    command.Parameters.AddWithValue("@Content", contact.Content);
                    command.Parameters.AddWithValue("@CreatedAt", DateTime.Now);
                    command.Parameters.AddWithValue("@UpdatedAt", DateTime.Now);
                    command.Parameters.AddWithValue("@UserId", contact.users_id);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ (ví dụ: ghi log, thông báo lỗi...)
                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public List<contact> GetContact()
        {
            var contacts = new List<contact>();

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    SqlCommand command = new SqlCommand()
                    {
                        Connection = connection
                    };

                    string query = "SELECT c.id, c.status, c.content, c.created_at, c.updated_at, c.users_id, u.name as UserName, u.email as UserEmail " +
                                   "FROM contact c " +
                                   "INNER JOIN Users u ON c.users_id = u.id";
                    command.CommandText = query;

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var contact = new contact();
                        contact.Id = (int)reader["id"];
                        contact.Status = (int)reader["status"];
                        contact.Content = (string)reader["content"];
                        contact.user = new User
                        {
                            Id = (int)reader["users_id"],
                            Name = (string)reader["UserName"],
                            Email = (string)reader["UserEmail"]
                        };
                        contact.Created_at = (DateTime)reader["created_at"];
                        contact.Updated_at = (DateTime)reader["updated_at"];
                        contacts.Add(contact);
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ (ví dụ: ghi log, thông báo lỗi...)
                Console.WriteLine(ex.Message);
            }

            return contacts;
        }
        public int GetTotalContacts()
        {
            int totalContacts = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    SqlCommand command = new SqlCommand()
                    {
                        Connection = connection
                    };

                    string query = "SELECT COUNT(*) FROM Contact";
                    command.CommandText = query;

                    connection.Open();
                    totalContacts = (int)command.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ (ví dụ: ghi log, thông báo lỗi...)
                Console.WriteLine(ex.Message);
            }

            return totalContacts;
        }
        public bool DeleteContact(int contactId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    string query = @"DELETE FROM Contact WHERE id = @ContactId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ContactId", contactId);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ (ví dụ: ghi log, thông báo lỗi...)
                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool SetContactStatus(int contactId, int status)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(dbconnection))
                {
                    connection.Open();

                    string query = @"UPDATE Contact SET status = @Status WHERE id = @ContactId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Status", status);
                    command.Parameters.AddWithValue("@ContactId", contactId);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                // Xử lý ngoại lệ (ví dụ: ghi log, thông báo lỗi...)
                Console.WriteLine(ex.Message);
                return false;
            }
        }




    }
}