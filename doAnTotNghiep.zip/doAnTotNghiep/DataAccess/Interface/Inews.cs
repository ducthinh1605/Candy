﻿using System;
using ECommerce.API.Models;
using ECommerce.API.Models.Request;
namespace ECommerce.API.DataAccess
{
    public interface Inews
    {
        bool insertNews(newsReq newreq);
        bool updateNews(newsReq newreq);
        List<news> GetAllNews();
        bool deleteNews(int newsId);
        news GetNewsById(int newsId);
        int GetTotalNews();
    }
}