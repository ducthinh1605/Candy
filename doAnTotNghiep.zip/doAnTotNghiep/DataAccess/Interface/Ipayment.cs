﻿using System;
using ECommerce.API.Models;
using ECommerce.API.Models.Request;
namespace ECommerce.API.DataAccess
{
    public interface Ipayment
    {
        bool InsertPayment(paymentMethod pay);
        paymentMethod GetPaymentById(int paymentId);
    }
}
