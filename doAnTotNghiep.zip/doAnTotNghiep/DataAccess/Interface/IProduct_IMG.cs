﻿using System;
using ECommerce.API.Models;
using ECommerce.API.Models.Request;

namespace ECommerce.API.DataAccess
{
    public interface IProduct_IMG
    {
        bool InsertProduct_img (product_IMGReq product_img);
        List<product_IMG> GetProduct_img();
        product_IMG GetProduct_imgById(int id);
        bool UpdateProduct_img(product_IMGReq product_img);
        bool DeleteProduct_img(int id);
        int GetTotalOfProIMG();
        List<product_IMG> GetProductImagesByProductId(int productId);
    }
}
