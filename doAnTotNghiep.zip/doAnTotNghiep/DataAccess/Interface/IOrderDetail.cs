﻿using System;
using System.Data.SqlClient;
using ECommerce.API.Models;
using ECommerce.API.Models.Request;
namespace ECommerce.API.DataAccess
{
    public interface IOrderDetail
    {
        List<orderDetails> GetOrderDetails(int orderId);
        List<orderDetails> GetORDByUserID(int userId);
        bool InsertOrder(orderReq order);
        string CreateEmailContentForCart(int orderId);
        bool SendEmailToUser(int userId);
        string GetUserEmailById(int userId);
    }
}
