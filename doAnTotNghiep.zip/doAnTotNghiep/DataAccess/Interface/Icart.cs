﻿using System;
using ECommerce.API.Models;
namespace ECommerce.API.DataAccess
{
    public interface Icart
    {
        bool InsertCart(int userId, int productId, int qty);
        bool DeleteCartItem(int userId, int productId);
        List<cart> GetCart(int userId);
        bool UpdateCart(int userId, int productId, int newQty);
    }
}
