﻿using System;
using ECommerce.API.Models;
namespace ECommerce.API.DataAccess
{
	public interface IAdmin
	{
		bool InsertAdmin(admin ad);
		List<admin> GetAdmin();
		admin GetAdminById(int id);
        bool GetAdminByAccAndPassword(admin ad);
        bool Update(admin ad);
        bool Delete(int id);
        int GetAdminId(string account, string password);
        //login admin, update, delete

    }
}

