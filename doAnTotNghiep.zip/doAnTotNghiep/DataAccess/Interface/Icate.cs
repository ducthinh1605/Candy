﻿using System;
using ECommerce.API.Models;
namespace ECommerce.API.DataAccess
{
    public interface Icate
    {
        bool insertCate(cate category);
        List<cate> GetCate();
        cate GetCateById(int id);
        bool UpdateCate(cate category);
        bool DeleteCate(int id);
        int GetTotalOfCate();
    }
}
