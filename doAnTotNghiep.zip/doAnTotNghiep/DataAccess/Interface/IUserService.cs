﻿using System;
using System.Data.Common;
using System.Data.SqlClient;
using ECommerce.API.Models;
namespace ECommerce.API.DataAccess
{
	public interface IUserService
	{
		bool InsertUser(User user);
		string HashPassword(string password);
		bool GetUserByAccAndPassword(User user);

        List<User> GetAllUser();
        User GetUser(int id);
		bool Update(User user);
		bool Delete(int id);
		int GetTotalOfUser();
		User GetUserInfo(string account, string password);
		void GenerateVerificationCode();
		//int getKey();
		bool SendVerificationCodeEmail(string email);
		bool CompareVerificationCode(int userInput);
		List<User> GetAllUserOrderByLatest();
		List<User> GetAllUserOrderByName();
	}
}

