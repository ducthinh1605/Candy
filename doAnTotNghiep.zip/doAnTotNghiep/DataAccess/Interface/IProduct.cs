﻿using System;
using ECommerce.API.Models;
using ECommerce.API.Models.Request;

namespace ECommerce.API.DataAccess
{
    public interface IProduct
    {
        bool InsertProduct(UpdateProductReq product);
        List<product> GetProducts();
        product GetProductById(int id);
        bool UpdateProduct(UpdateProductReq product);
        bool DeleteProduct(int id);
        int GetTotalOfPro();
        List<string> GetProductImagesById(int productId);
        List<product> GetProductsByCategory(string nameCategory, int count);
        List<product> GetProductsBySupplier(string nameSupplier, int count);
        product SearchProductsByName(string keyword);
        int ComputeLevenshteinDistance(string s, string t);
        string RemoveAccents(string text);
        List<product> GetSimilarProductsByCategory(int productId);
        List<product> GetTopSellingProducts();
        List<product> GetLatestProducts();
        List<product> GetProductsByExpirationDescending();
    }
}
