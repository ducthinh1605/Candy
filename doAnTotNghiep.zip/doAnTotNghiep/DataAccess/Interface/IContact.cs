﻿using System;
using ECommerce.API.Models;
using ECommerce.API.Models.Request;


namespace ECommerce.API.DataAccess
{
    public interface  IContact
    {
        bool insertContact(contactReq contact);
        List<contact> GetContact();
        int GetTotalContacts();
        bool DeleteContact(int contactId);
        bool SetContactStatus(int contactId, int status);
    }
}
