﻿using System;
using ECommerce.API.Models;
using ECommerce.API.Models.Request;
namespace ECommerce.API.DataAccess
{
    public interface IOrder
    {
        //bool InsertOrder(orderReq order);
        List<orders> GetOrdersById(int id);
        List<orders> GetOrders();
        int GetTotalOrders();
        bool SetOrderStatus(int orderId, int newStatus, int userId);
        List<orders> GetOrdersByUserId(int userId);
        bool DeleteOrder(int orderId);
        bool DeleteOrderByUser(int orderId);
        List<orders> GetOrdersByStatus(int status);
        List<orders> GetConfirmOder(int userId);

        //Dictionary<string, int> GetTotalAmountWithinPeriod(DateTime startDate, DateTime endDate);
        public int GetTotalAmountWithinPeriod(DateTime startDate, DateTime endDate);
        public int GetTotalSoldProductsWithinPeriod(DateTime startDate, DateTime endDate);
        public List<orderDetails> GetOrderDetails(int orderId);
        public int GetTotalSoldOrdersWithinPeriod(DateTime startDate, DateTime endDate);
        List<UserSpendingInfo> GetTop10UsersWithHighestSpending(DateTime startDate, DateTime endDate);

    }
}
