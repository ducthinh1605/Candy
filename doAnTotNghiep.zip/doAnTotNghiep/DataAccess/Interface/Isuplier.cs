﻿using ECommerce.API.Models;
namespace ECommerce.API.DataAccess
{
    public interface Isuplier
    {
        bool insertSup(suplier sup);
        List<suplier> GetSup();
        suplier GetSupById(int id);
        bool UpdateSup(suplier sup);
        bool DeleteSup(int id);
        int GetTotalOfSup();
    }
}