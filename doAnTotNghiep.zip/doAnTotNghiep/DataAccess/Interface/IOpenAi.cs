﻿using System;
using System.Data.Common;
using System.Data.SqlClient;
using ECommerce.API.Models;
namespace ECommerce.API.DataAccess
{
    public interface IOpenAi
    {
        Task<string> GenerateTextAsync(string prompt);
    }
}